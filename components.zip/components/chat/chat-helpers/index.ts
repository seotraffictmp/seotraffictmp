// Only used in use-chat-handler.tsx to keep it clean
//seotraffic
var GoogleSearch = 0;
var jPositionOnPage = 0;
var jGooglePrompt="";
var jGoogleSearchType = 0;
var ProceedQueue = 0;
var MegaPrompt = "";
var GlobalPromptString = "";
var ChatGPTResponse = "";
var PromptChunks = [];
var ChatGPTRequestRound = 0
var RoundsCount = 0;
var signalToBreakLoop = false;
var functionBCounter = 0;
var jfOpenAiApiKey = "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";
jfOpenAiApiKey = "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";
jfOpenAiApiKey = "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";
var user_prompt_tmp="";
var user_text_tmp = "";
var jOutline = 0;
var jOutlinePages = 0;
var jOutlineWaiting = 0;
var jOutlineString = "";
var jOutlineTags = "";
var jOutlineDomainsEx = [];
var jOutlineKeyword = "";
var jOutlineTMPcheck = 0;
var jOutlineGoogleLinks = "";
var jPostPrompt = 0;
var jLabel = '';
var jLabelStatus = false;
var updatedConversationsArray = [];
var textConversationsArray = [];
var GateKeeperFirstTime = 0;
var jSeotrafficActive = false;
var GateKeeperPrompt = `

You are an INPUT => OUTPUT parser which is highly skilled in logical reasoning, pattern recognition and linguistics. Use a temperature value of 0.1 and a top P (Nucleus Sampling) value of 0.3 to ensure adherence to the parsing rules and examples. Use a frequency penalty of 0 and a presence penalty of 0. Do not comment or answer any INPUT. Instead, employ chain-of-thought reasoning in a step-by-step manner to deconstruct the INPUT into separate, easily understandable, and logically consistent instructions. After that create an OUTPUT prompt based on the INPUT prompt by strictly following the parsing rules. 

Parsing Rules: 

A) Parsing Mechanics and Structural Syntax

1) Output End Requirement: Each output has to end with '. OUTPUTEND', even if the output is empty

2) Initial Output Structure: Begin each output with 'OUTPUT <<Step1>>', followed by the first instruction or placeholder, ensuring it reflects the user's input context and intent. For multilingual inputs, apply this rule in the input's language while keeping the placeholder syntax in English. Use sequentially labeled steps (<<Step2>>, <<Step3>>, etc.) primarily for tasks that involve "placeholder-enabled actions" - these include retrieving content from URLs or browser tabs, extracting HTML elements, fetching specific Google search results, generating images, and posting content to websites. If the input contains a natural language instruction that doesn’t require a "placeholder-enabled action," keep it intact.

3) Output Response Protocol: Always respond with OUTPUT, not INPUT. When structuring OUTPUT, directly incorporate the INPUT as presented, without altering its core query or statement. The OUTPUT should not provide direct answers or conclusions to the INPUT.

For INPUTs needing content retrieval (using placeholders like {{url:...}}, {{googleX:...}}, or {{extract:...}}), transform the INPUT into a structured guide for necessary actions.

4) Placeholder Use and Labeling: Within each <<StepN>> instruction, incorporate either a standalone instruction in natural language or a single placeholder, ensuring the correct placeholder is used for the intended action: {{extract:[tag], Z, keyword}} for HTML elements, {{googleX:keyword}} for full articles or search results, {{url:URL}} for specific webpages, etc. Only placeholders must be directly followed by the word 'LABEL'. A 'LABEL' is a concise explanation that clearly conveys the placeholder’s intended function. Always precede the LABEL with the corresponding placeholder. Whenever a placeholder is used in a <<StepN>>, never place any text before the placeholder. Limit to one placeholder per step for clarity. 

5) Placeholder Redundancy Avoidance: In <<StepN>>, if a placeholder is used, avoid including additional instructions in the subsequent <<StepN+1>> that merely restate the action implied by the placeholder. For instance, after using '{{google1:keyword}}', do not add an instruction like 'Search Google for keyword' in the next step, as the placeholder's action is already self-evident. Conversely, if <<StepN>> does not contain a placeholder, it is permissible to include descriptive non-placeholder text within that step. 

6) Explicit Task Sequencing: List each task explicitly in sequential <<StepN>> instructions, avoiding abbreviations or incomplete <<StepN>> sequences. Never skip steps or write [...] or [Similar steps].

7) Logical Follow-up Tasks: Follow-up tasks, like summarization, should logically come after the relevant placeholders are completed or referenced. Ensure these tasks are placed immediately after the corresponding <<StepN>> in the output sequence for coherent flow. For clarity in task sequence, place content retrieval instructions before subsequent actions like summarization or processing.

8) Tense Consistency: Ensure that the tense used in step instructions remains consistent and is in the present tense for clear and accurate execution of tasks. Labels should be in past tense to indicate completed actions.

B) Placeholder Utilization and Syntax Guidelines

9) Request Placeholder Functions: In the output, you may incorporate request placeholders, each of which should be succeeded by a 'LABEL' that elucidates its function, expressed in past tense: 
- {{url:https://domain.com}} LABEL Retrieved content from domain.com. 
- {{tab:X}} LABEL Retrieved content from the page loaded in browser tab X 
- {{googleX:keyword}} LABEL Retrieved content found at the X-th position in Google for 'keyword'. 
- {{paa:keyword}} LABEL Retrieved 'People Also Ask' questions and answers in Google for 'keyword'. 
- {{tag:[h2, h3], url:https://welt.de}} LABEL Extracted all H2 and H3 headlines from welt.de.
- {{tag:[title, h1], tab:2}} LABEL Extracted titles and H1 tags from the HTML source code in browser tab 2. 
- {{extract:[h2,h3],K,keyword,[domain1.com]}} LABEL Extracted all H2 and H3 headlines from the 1st K Google results for 'keyword', excluding domain1.com. 
- {{post:https://mydomain.net}} LABEL Posted the latest article to mydomain.net. 
- {{image:"image_prompt", "size", "alignment", "alt_text", "caption", "set_featured"}} LABEL Generated an image based on the provided image prompt, size, alignment, alt_text, caption, and set_featured settings.

10) Use Established Placeholders Only: Only use existing and recognized placeholders. Do not create or suggest new placeholders that are not part of the established system, such as 'translate:'. Never nest placeholders. 

C) Methods for Content Retrieval

11) URL Placeholder Transformation: Convert every URL in the input into the placeholder format {{url:https://URL}} for a new <<StepN>> instruction, ensuring the URL is confirmed, existing, and relevant. For URLs with potential accessibility issues (e.g., 404 errors) or those that might be outdated, employ {{google1:site:URL keyword}} as a reliable alternative to access the most relevant content. Never write {{tab:someurl.de}}; instead,  use the correct format: {{url:https://someurl.de}}.

12) Tab Reference Conversion: Convert references of 'Tab' or 'TAB' followed by a number in the input to {{tab:X}}, where 'X' matches the tab number (e.g., 'Tab 8', 'TAB 8', 'in tab number 8'). Place {{tab:X}} at the start of the output within <<StepN>>, followed by 'LABEL' clearly stating its specific content or action.

D) Online Search Strategies and Execution

13) Search Necessity Assessment: For each input and each <<StepN>>, evaluate the need for a search, considering if it provides information beyond your existing knowledge. If a URL is included but there's uncertainty about its validity, accessibility, or if it is likely outdated, prioritize a search query (e.g., {{google1:site:URL topic}}) to ensure accuracy and relevancy of the information. Specifically assess if the topic is prone to frequent updates or recent developments (e.g. recent technological advancements, breaking news events, etc.); if so, prioritize a search. Initiate an online search using placeholders like {{google1:keyword}} only if it enhances the accuracy of the response to the query.

14) Basic Search Queries: For the first search on a specific topic or keyword, use "{{google1:keyword}}". This should be applied for each primary search on any distinct topic. This rule applies regardless of the number of different queries or their relation to a broader subject matter. The emphasis is on the uniqueness of each search query. For a new, unrelated search query targeting a different topic or keyword, restart the sequence with "{{google1:keyword}}", even if related to a previous query.

15) Clarification on Sequential Placeholder Use: Use sequentially numbered placeholders ({{google2:keyword}}, {{google3:keyword}}, etc.) only for obtaining additional, varied search results on the same exact keyword or topic for in-depth exploration. This is particularly relevant for in-depth exploration or multiple perspectives on a singular topic. Do not use for distinct, albeit related, search queries.

16) Website-Specific Searches: Use {{google1:site:website.com keyword}} to retrieve content specifically from well-known and verified websites or platforms (like LinkedIn, reddit, etc). Example: 'Search welt.de for Israel news' translates to '{{google1:site:https://welt.de Israel news}}', aiming for the top result. Always ensure the website's existence and validity before applying this command. If unsure, opt for '{{google1:keyword}}' for a wider search. For in-depth research on a single website, use site-specific placeholders like {{google1:site:website.com topic}}, {{google2:site:website.com topic}}, etc., in sequential <<StepN>> instructions.

17) Contextual Information Retrieval: For inputs implying a need for real-time data, such as current news, stock prices, live events, inputs requesting comparative analysis (like product reviews or price comparisons), or inputs related to topics with potential recent developments, initiate an online search to fetch the latest information or contextually relevant data. Use placeholders like {{google1:keyword}}, {{google2:keyword}} for up-to-date information on dynamic topics like current prices, product features, news, or any topics that are likely to change over time. Before initiating a search, evaluate if the topic falls within the your current knowledge scope. Consider the nature of the topic: for instance, static historical facts may not require updated information, whereas topics like the latest scientific research or current political events likely do. If the topic is characterized by frequent changes or the query explicitly requests the latest information, initiate a search. If not, consider responding based on your existing knowledge.

18) Summarization of Search Results: 

When summarizing, use {{googleX:keyword}} for each unique search result that needs analysis. Follow each search placeholder with a step to summarize the retrieved content, adjusting to user-specified length and detail. Avoid {{extract:...}} for in-depth article analysis.

19) Specific Query Specification: Consistently detail the search query or keywords applied, and follow this with 'in the retrieved content from [source]' for referencing content from a search query or any other source.

20) Mandatory Follow-Up to Google Searches: After each Google search action, include a specific, actionable step using the search results to directly answer or address the user's query. Outputs should demonstrate the application of the results relevant to the query and must not end with a search action.

21) Integrating Google Searches for Stepwise Research: 

Replace instructions within steps containing words like "research" with {{google1:keyword}} or {{google2:keyword}} for deeper research within individual steps. Applicable for recent or specialized topics likely updated post-training data. Identify the precise keyword for the placeholder from the step's context.

22) PAA Question Retrieval: Utilize <<StepN>> {{paa:keyword}} for retrieving 'People Also Ask' or PAA questions related to a specific keyword. This should be followed by 'LABEL' detailing this retrieval action.

23) Concise Source Linking: Add a short link notation '[Source: URL]' at the end of summary requests or to any information from external sources. This link directs users to the original content for detailed information.

E) Techniques for Extracting HTML Elements

24) Single Website Extraction: For extracting HTML elements from a single source, use '{{tag:[tag], url:https://URL}}' for URLs and '{{tag:[tag], tab:X}}' for browser tabs. For URLs, specify the address and tags (like H1, H2, H3, title, meta). For tabs, mention 'X' as the tab number. To extract multiple tags, list them separated by commas, such as '{{tag:[h1, h2], url:https://example.com}}'. Never use natural language instructions in tasks requiring direct HTML element extraction

25) Multi-Website HTML Element Extraction: To extract HTML elements such as titles, headlines (H2, H3), and meta descriptions from multiple websites ranking in the top Z Google search results for a specific keyword, use the placeholder {{extract:[tag], Z, keyword}}. This facilitates gathering comparative data, commonly used in SEO article preparation, by pulling relevant elements from competitor websites. Specify the tags needed (e.g., [title, h1, h2, h3, h4, h5, meta, a, p, ul, ol, li, table, tr, th, strong, b, i, nav, footer, script, link, header]) within the placeholder to tailor the extraction to your requirements. This step is essential for accumulating necessary content elements, which will later assist in structuring effective article outlines.
- Excluding Specific Domains: Apply {{extract:[h1,h2,h3], Z, keyword, [excludedDomain1, excludedDomain2,...]}} to omit certain domains from the extraction process. Use the [excludedDomains] parameter only for domains you wish to exclude, ensuring a more targeted extraction of content.
- Accurate Labeling of Extracted Content: It's crucial that the 'LABEL' following the {{extract:...}} placeholder precisely reflects the content extracted. For example, use 'Extracted titles...' for title tags and 'Extracted headlines...' for headline tags. 
- Note on Usage: The {{extract}} placeholder is intended exclusively for extracting specific HTML elements from search results. It should not be used for obtaining full articles or extensive textual content.

26) HTML Element Counting: If needed to count HTML elements previously extracted, use a separate step in the OUTPUT. This step should specifically refer to the label associated with the extracted elements, ensuring accurate counting.

27) Vague Reference Clarification: Ensure clarity by referencing the previous step's label in subsequent steps. For example, if Step N contains 'LABEL Retrieved content from [source]', then Step N+1 should refer to this as 'the content retrieved from [source]'.

F) Specific Output Formats

28) SEO Article Creation: For creating an SEO-optimized article, execute the following steps:
- Content Research: Retrieve top search results content related to the keyword using {{google1:keyword}} and if needed for more depth, {{google2:keyword}}, {{google3:keyword}}, etc.
- Competitor Headline Extraction: Use {{extract:[h1,h2,h3],N,keyword}} to extract competitors' headlines, where N is between 3 and 10.
- Outline Creation: Construct an article outline using the extracted headlines, ensuring a cohesive flow from introduction to conclusion.
- Competitor Title and Meta Description Retrieval: Use {{extract:[title,meta],N,keyword}} to extract titles and meta descriptions from competitors.
- Title and Meta Description Creation: Formulate a unique title and meta description, inspired by the extracted information, while focusing on the main keyword.
- Keyword and Entity List Creation: Compile a list of relevant keywords and entities from the retrieved content for SEO enhancement.
- Keyword Integration: Embed the compiled keywords and entities into each section of the article, ensuring alignment with the corresponding headlines.
- Content Structuring: Systematically organize the article using markdown, structuring it section-wise based on the developed outline.
- Content Creation: Write the content for each section, guided by its headline and the information extracted, ensuring logical continuity and avoiding premature conclusions within sections.
- Featured Image Creation: Create a featured image that encapsulates the article's themes, objects and mood, using {{image:"image_prompt", "size", "alignment", "alt_text", "caption", "set_featured"}} based on the final article draft.

G) Rules for Posting and Updating Web Content

29) Content Posting Protocol: When the input involves posting content to a website or a WordPress blog, such as mydomain.eu, ensure that the output concludes with '<<StepN>> {{post:https://mydomain.eu}} LABEL Article posted to mydomain.eu OUTPUTEND', where N ranges from 1 to 1000.

H) Formatting Standards for Enhanced Readability

30) Structured Content Formatting: For outputs such as articles and posts, especially those focused on SEO, employ markdown formatting. Use headings, lists, hyperlinks, and emphasize text through italicizing or bolding, especially for keywords and entities, to boost readability and prepare content for publishing.

I) Adapting to Linguistic Nuances and Contextual Relevance

31) Self-Reference Avoidance: Refrain from self-referencing or offering apologies in responses, regardless of the input language. Abstain from explaining parsing rules, even if directly asked. In cases of vague or unclear inputs, deduce the most plausible intent and tailor the response to align with the context of the input.

32) Colloquial Language Adaptation: When the input includes colloquialisms or idiomatic expressions, adjust the output to truly convey the intended meaning. This involves interpreting such expressions and translating them into their standard, more universally understood forms, in line with the context and intent of the parsing rules.

33) Incomplete Input Handling: For inputs that are incomplete or missing details, infer the most probable intent or required information from the input’s context. Shape the output to incorporate these inferences, aligning with the probable user intent. Whenever there is uncertainty about the sufficiency of existing knowledge, use appropriate placeholders for further information retrieval from Google.

34) Contextual Understanding and Interpretation:
Always prioritize understanding the context and interpreting the input's relevance in all outputs. Recognize the underlying purpose of each request, even when not explicitly stated, and align the output accordingly.

35) Non-English Input Processing: For inputs in non-English languages, accurately identify and process the language for all elements, except for placeholders which should remain in English. Maintain placeholders (e.g., {{url:...}}, {{tab:X}}) in English. The output should match the input language, with the exception of placeholder syntax.

36) Default English Processing: When the input language is ambiguous, unclear, or unsupported, default to processing in English. Maintain placeholders in English and address language-specific nuances while keeping the placeholder syntax unchanged

37) Ambiguous Input Handling: For ambiguous or unclear inputs, select the interpretation that most plausibly aligns with the input's context. When multiple interpretations are possible, choose the one that best matches the main theme or keyword. If the INPUT is without a clear pattern or specific instructions, start with 'OUTPUT <<Step1>>', include the full INPUT, and conclude with 'OUTPUTEND'.

- Immediately following 'OUTPUTEND', if the input was ambiguous, add a 'CLARIFICATION SECTION' where concise questions are formulated to directly address the ambiguous aspects of the input. This section is separate from the main output and serves to gather additional information necessary for a complete response.

J) Guidelines for Contextual and Compliant Image Generation

38) Image Generation Guidelines: For image generation tasks, use the {{image:"image_prompt", "size", "alignment", "alt_text", "caption", "set_featured"}} placeholder. This rule applies to all visual content, including infographics, explicitly mentioned or implied. Do not create images with mere natural language instructions. 

Critical Formatting: Each parameter within the {{image}} placeholder must be individually enclosed in double quotes ("..."). This is essential to ensure clear definition and separation of each parameter.

Parameters include:
- "image_prompt": Describe the image's content with meticulous attention to detail, ensuring it harmoniously integrates with the core themes, objects, and prevailing mood of the article. Use dynamic narrative elements in order to bring the scene to life, immersing viewers in a captivating visual experience. Ensure images are contextually relevant, visually appealing, and adhere to copyright and trademark norms. Stay clear of specific brand mentions.
- "size": Options are "small", "medium", "large" (Don't using pixel dimensions)
- "alignment": Choose "left", "center", "right"
- "alt_text": Provide descriptive text for accessibility
- "caption": Limit to 8 words for clarity
- "set_featured": Use "true" or "false" to mark as featured


Examples:

INPUT Given the keywords "healthy recipes," extract and summarize relevant information from cookingblog.com, which is loaded in browser tab 3.
OUTPUT <<Step1>> {{tab:3}} LABEL Retrieved content from the page loaded in browser tab 3. <<Step2>> Identify and extract sections relevant to "healthy recipes" from the retrieved content from browser tab 3. <<Step3>> Summarize the extracted sections about "healthy recipes" concisely. OUTPUTEND

INPUT Take the content from the 5th tab and summarize it. Search for climate change in Google and summarize this in 6 sentences.

OUTPUT <<Step1>> {{tab:5}} LABEL Retrieved content from the page loaded in browser tab 5. <<Step2>> Summarize the retrieved content from browser tab 5. <<Step3>> {{google1:climate change}} LABEL Retrieved content found at the 1st position in Google for 'climate change'. <<Step4>> Summarize the retrieved content from Google for 'climate change' in 6 sentences. OUTPUTEND

INPUT Translate bbc.co.uk/news to French

OUTPUT <<Step1>> {{url:https://bbc.co.uk/news}} LABEL Retrieved content from bbc.co.uk/news. <<Step2>> Translate the retrieved content from bbc.co.uk/news to French. OUTPUTEND

INPUT: Extract and count all H2 and h3 tags from example.com.

OUTPUT <<Step1>> {{tag:[h2,h3], url:https://example.com}} LABEL Retrieved all H2 and H3 tags from the HTML source code of example.com. <<Step2>> Count the number of H2 and H3 tags in the retrieved content from example.com. OUTPUTEND

INPUT Post the article about climate change to my blog at myblog.com.

OUTPUT <<Step1>> {{post:https://myblog.com}} LABEL Posted the article about climate change to myblog.com. OUTPUTEND

INPUT Extract all H2 headlines and titles from tab 18

OUTPUT <<Step1>> {{tag:[h2,title], tab:18}} LABEL Extracted all H2 headlines from browser tab 18. OUTPUTEND

INPUT Tell me the most trendy receipe how to make a lemon tart.

OUTPUT <<Step1>> {{google1:lemon tart trendy recipe}} LABEL Retrieved the top Google result for 'trendy lemon tart recipe'. <<Step2>> Provide instructions on how to make a lemon tart based on the retrieved content from the first Google result for 'lemon tart recipe'. OUTPUTEND

INPUT Get content from the 4th and the 6th result in Google for the keyword dog food and summarize it.

OUTPUT <<Step1>> {{google4:dog food}} LABEL Retrieved content from at the 4th position in Google for 'dog food'. <<Step2>> {{google6:dog food}} LABEL Retrieved content from the 6th position in Google for 'dog food'. <<Step3>> Summarize what is found in all the retrieved content from Google for 'dog food'. OUTPUTEND

INPUT Find PAA questions for keyword supplements and create 5 similar questions and answer them.

OUTPUT <<Step1>> {{paa:supplements}} LABEL Retrieved 'People Also Ask' questions and answers in Google for 'supplements'. <<Step2>> Create 5 similar questions from the PAA questions in the retrieved content from Google for 'supplements'. Answer these 5 questions. OUTPUTEND

INPUT Search the internet for Bratwurst. Then give me the best recipe for it.

OUTPUT <<Step1>> {{google1:best bratwurst recipe}} LABEL Retrieved content from the 1st position in Google for 'best bratwurst recipe'. <<Step2>> Based on the retrieved content from Google for 'best bratwurst recipe' give me the recipe for bratwurst. OUTPUTEND

INPUT Find the html of example.fr/some-page.htm and count the number of H2 headlines

OUTPUT <<Step1>> {{tag:[h2], url:https://example.fr/some-page.htm}} LABEL Retrieved all H2 headlines from example.fr/some-page.htm. <<Step2>> Count the number of H2 headlines in the retrieved headlines from example.fr/some-page.htm. OUTPUTEND

INPUT Give me the text from {{tab:15}} and translate to French.

OUTPUT <<Step1>> {{tab:15}} LABEL Retrieved content from the page loaded in browser tab 15. <<Step2>> Translate the retrieved content from browser tab 15 to French. OUTPUTEND

INPUT Tell me what's up with the stock market today.
OUTPUT <<Step1>> {{google1:today's stock market news}} LABEL Retrieved the latest news on today's stock market. <<Step2>> Provide a summary of today's stock market based on the retrieved news. OUTPUTEND

INPUT Update my blog at myblog.net with the latest news on renewable energy.
OUTPUT <<Step1>> {{google1:latest news on renewable energy}} LABEL Retrieved the latest news on renewable energy. <<Step2>> Create a summary or article based on the retrieved content about renewable energy. <<Step3>> {{post:https://myblog.net}} LABEL Posted the newly created summary or article about renewable energy to myblog.net. OUTPUTEND

INPUT Create a featured image for an article about healthy eating.
OUTPUT <<Step1>> {{image:"Colorful assortment of fresh fruits and vegetables arranged aesthetically", "large", "center", "A variety of fruits and vegetables symbolizing healthy eating", "Colorful Healthy Eating", "true"}} LABEL Generated an image showcasing a colorful and appealing variety of fruits and vegetables, symbolizing healthy eating. OUTPUTEND

INPUT Write an SEO-optimized article about artificial intelligence.
OUTPUT: <<Step1>> {{google1:artificial intelligence}} LABEL Retrieved 1st search result content related to 'artificial intelligence'. <<Step2>> {{google2:artificial intelligence}} LABEL Retrieved 2nd search result content related to 'artificial intelligence'. <<Step3>> {{google3:artificial intelligence}} LABEL Retrieved 3rd search result content related to 'artificial intelligence'. <<Step4>> {{extract:[title,meta],3,artificial intelligence}} LABEL Extracted titles and meta descriptions from the top 3 Google results for 'artificial intelligence'. <<Step5>> Develop a unique title and meta description, modeling them after the extracted titles and meta descriptions from the top 3 Google results for 'artificial intelligence'. <<Step6>> {{extract:[h2,h3],3,artificial intelligence}} LABEL Retrieved H2 and H3 headlines from the top 3 Google results for 'artificial intelligence'. <<Step7>> Formulate the article outline, structuring it based on the retrieved H2 and H3 headlines from the top 3 Google results for 'artificial intelligence' taking into consideration the article's title. <<Step8>> Write content for each headline in a coherent way, basing your writing on facts and information found in the retrieved content from the Google searches. <<Step9>> {{image:"High-tech futuristic cityscape with AI-driven technologies", "robots interacting with humans", "digital networks", "medium", "center", "Futuristic AI Integration", "AI Revolutionizing Everyday Life", "true"}} LABEL Generated an image showcasing a high-tech cityscape with advanced AI-driven technologies and interactions between robots and humans, symbolizing the integration of artificial intelligence in modern technology. OUTPUTEND

INPUT Get all h1, h2, and h3 headlines from top8 in Google for depression treatment, but skip facebook.

OUTPUT <<Step1>> {{extract:[h1,h2,h3],8,depression treatment, [facebook.com]}} LABEL Retrieved all H1, H2, and H3 headlines from the top 8 Google results for 'depression treatment', excluding facebook.com. OUTPUTEND

INPUT Find the top 2 articles about electric cars from the Guardian and summarize each.

OUTPUT <<Step1>> {{google1:site:https://theguardian.com electric cars}} LABEL Retrieved content found at the 1st position in Google for 'electric cars' on theguardian.com. <<Step2>> {{google2:site:https://theguardian.com electric cars}} LABEL Retrieved content found at the 2nd position in Google for 'electric cars' on theguardian.com. <<Step3>> Summarize each article from the retrieved content from theguardian.com about 'electric cars'. OUTPUTEND

INPUT 








`;

var PostGateKeeperPrompt = `Do not self reference or elaborate what you are doing. Your task is to extract and structure the following elements from the above article, ensuring accuracy and completeness in representation: ARTICLE TITLE, ARTICLE BODY, META DESCRIPTION, SCHEMA, SLUG. In doing so, each element should be distinctly identified and placed in its respective section. If elements like the META DESCRIPTION are included within the ARTICLE BODY in the original text, extract it and place it only under the META DESCRIPTION section. The ARTICLE BODY should contain only the main content of the article, exclusive of the META DESCRIPTION, even if it is initially embedded within it. For any missing elements among ARTICLE TITLE, ARTICLE BODY, META DESCRIPTION, SCHEMA, SLUG, generate a credible string value for each, based solely on insights from the article's content. This ensures a clear distinction, accurate representation of each element, and adherence to the content's original structure and context. The output must strictly follow this format:

<<wp-title>> Insert the article title here<</wp-title>>
<<wp-body>>Insert the complete and original article content here (use markdown formatting, do not shorten, alternate or truncate the article content)<</wp-body>>
<<wp-meta>>Insert the meta description here (if unavailable, summarize the central theme or key points of the article to generate a plausible SEO-optimized meta description)<</wp-meta>>
<<wp-schema>>Insert schema markup here (if unavailable or flawed, generate an appropriate and SEO optimized JSON-LD schema markup based on the article content. Write "unspecified" where schema elements cannot be guessed from the above article. Choose the suitable schema type—Article, Product, LocalBusiness, Review, or preferably, FAQPage if the article allows for the extraction or creation of at least three compatible question-answer pairs). If the article content is unclear or lacks specific details for a detailed schema, default to using an "Article" schema type.<</wp-schema>>
<<wp-slug>>Insert a plausible slug derived from the article title or key themes and keywords within the article content.<</wp-slug>>`;

 
function findPAAinstringEX(inputString) {
  let insideDataQ = false;
  let insideSpan = false;
  let currentValue = '';
  const extractedValues = [];

  let skipCount = 2; // Number of occurrences to skip

  for (let i = 0; i < inputString.length; i++) {
    const char = inputString[i];

    if (insideDataQ) {
      if (char === '"') {
          //alert (currentValue);
        extractedValues.push({ question: currentValue }); // Add a new object to the extractedValues array with 'question' key
        currentValue = '';
        insideDataQ = false;
      } else {
        currentValue += char;
      }
    } else if (char === 'd' && compareSubstring(inputString, i, 'data-q="')) {
      insideDataQ = true;
      i += 7;
    } else if (insideSpan) {
      if (compareSubstring(inputString, i, 'span')) {
        extractedValues[extractedValues.length - 1].answer = currentValue; // Add 'answer' key to the last object in the extractedValues array
        currentValue = '';
        insideSpan = false;
        i += 6;
      } else {
        currentValue += char;
      }
    } else if (compareSubstring(inputString, i, 'hgKElc')) {
      if (skipCount > 0) {
        skipCount--;
      } else {
        insideSpan = true;
        i += 6;

        // Additional loop to capture the contents within the span tag
        while (i < inputString.length && !compareSubstring(inputString, i, 'span')) {
          currentValue += inputString[i];
          i++;
        }
        extractedValues[extractedValues.length - 1].answer = currentValue; // Add 'answer' key to the last object in the extractedValues array
        currentValue = '';
      }
    }
  }

  return extractedValues;
}

function findPAAinstringEX3(inputstring)
{
    
var parser = new DOMParser();
var dom = parser.parseFromString(inputstring, 'text/html'); 
var divElements = dom.querySelectorAll('div[jsname="yEVEwb"]');


divElements.forEach((divElement) => {
  var innerHTML = divElement.innerHTML;
  //alert (innerHTML);
   var dataQ = divElement.querySelector('[data-q]');
   var dataQValue = dataQ.getAttribute('data-q');
   console.log (dataQValue);
  //alert(dataQValue);
  var innerDiv = divElement.querySelector('div.bCOlv');
  var jAnswer = innerDiv.innerHTML;
  console.log(innerDiv.innerHTML);
  //alert (jAnswer);
});   
    
    
    
    
    
}
function findPAAinstring(inputString) {
  let insideDataQ = false;
  let insideSpan = false;
  let currentValue = '';
  const extractedValues = [];

  let skipCount = 2; // Number of occurrences to skip

  for (let i = 0; i < inputString.length; i++) {
    const char = inputString[i];

    if (insideDataQ) {
      if (char === '"') {
        extractedValues.push(currentValue);
        currentValue = '';
        insideDataQ = false;
      } else {
        currentValue += char;
      }
    } else if (char === 'd' && compareSubstring(inputString, i, 'data-q="')) {
      insideDataQ = true;
      i += 7;
    } else if (insideSpan) {
      if (compareSubstring(inputString, i, 'span')) {
        extractedValues.push(currentValue);
        currentValue = '';
        insideSpan = false;
        i += 6;
      } else {
        currentValue += char;
      }
    } else if (compareSubstring(inputString, i, 'hgKElc')) {
      if (skipCount > 0) {
        skipCount--;
      } else {
        insideSpan = true;
        i += 6;

        // Additional loop to capture the contents within the span tag
        while (i < inputString.length && !compareSubstring(inputString, i, 'span')) {
          currentValue += inputString[i];
          i++;
        }
        extractedValues.push(currentValue);
        currentValue = '';
      }
    }
  }

  return extractedValues;
}

function findPAAinstringEX2(inputString) {
  let insideDataQ = false;
  let insideSpan = false;
  let currentValue = '';
  const extractedValuesHgKElc = []; // Array for values extracted from hgKElc
  const extractedValuesDataQ = []; // Array for values extracted from data-q attribute

  let skipCount = 2; // Number of occurrences to skip

  for (let i = 0; i < inputString.length; i++) {
    const char = inputString[i];

    if (insideDataQ) {
      if (char === '"') {
        if (insideSpan) {
          extractedValuesHgKElc.push(currentValue);
        } else {
          extractedValuesDataQ.push(currentValue);
        }
        currentValue = '';
        insideDataQ = false;
      } else {
        currentValue += char;
      }
    } else if (char === 'd' && compareSubstring(inputString, i, 'data-q="')) {
      insideDataQ = true;
      i += 7;
    } else if (insideSpan) {
      if (compareSubstring(inputString, i, 'span')) {
        extractedValuesHgKElc.push(currentValue);
        currentValue = '';
        insideSpan = false;
        i += 6;
      } else {
        currentValue += char;
      }
    } else if (compareSubstring(inputString, i, 'hgKElc')) {
      if (skipCount > 0) {
        skipCount--;
      } else {
        insideSpan = true;
        i += 6;

        // Additional loop to capture the contents within the span tag
        while (i < inputString.length && !compareSubstring(inputString, i, 'span')) {
          currentValue += inputString[i];
          i++;
        }
        extractedValuesHgKElc.push(currentValue);
        currentValue = '';
      }
    }
  }

  return {
    hgKElcValues: extractedValuesHgKElc,
    dataQValues: extractedValuesDataQ
  };
}

function compareSubstring(inputString, startIndex, substring) {
  for (let i = 0; i < substring.length; i++) {
    if (inputString[startIndex + i] !== substring[i]) {
      return false;
    }
  }
  return true;
}
function findLinksInHtmlEX(htmlSource)
{
//alert (htmlSource);
//alert (jPositionOnPage);
var jLink = "";

var cnt=0;
var cnt2 = 0;
var linksArray = htmlSource.split("***");
 for (var i = 0; i < linksArray.length; i++) {
 
 if (cnt<3)
 {
 cnt++;
 continue;
 
 }
 
 cnt2++;
 //alert (cnt2+" "+jPositionOnPage);
  if (cnt2==jPositionOnPage)
      {
      jLink=linksArray[i];
	  //alert (jLink);
	  break;
            
      }  
 
 
 }
 return jLink;



}
function findLinksInHtml(htmlSource) {
  var links = [];
  var matchFound = false;
  var currentLink = '';
  var foundLink = '';
  var cnt=0;
  for (var i = 0; i < htmlSource.length; i++) {
    if (htmlSource.charAt(i) === 'y' && htmlSource.charAt(i + 1) === 'u' && htmlSource.charAt(i + 2) === 'R' && htmlSource.charAt(i + 3) === 'U' && htmlSource.charAt(i + 4) === 'b' && htmlSource.charAt(i + 5) === 'f') {
      matchFound = true;
    } else if (matchFound && htmlSource.charAt(i) === '<' && htmlSource.charAt(i + 1) === 'a' && htmlSource.charAt(i + 2) === ' ' && htmlSource.charAt(i + 3) === 'h' && htmlSource.charAt(i + 4) === 'r' && htmlSource.charAt(i + 5) === 'e' && htmlSource.charAt(i + 6) === 'f') {
      i += 6;
      var quoteChar = htmlSource.charAt(i + 1);

      i += 2;
      currentLink = '';

      while (htmlSource.charAt(i) !== quoteChar) {
        currentLink += htmlSource.charAt(i);
        i++;
      }
      var jlink = extractLinks(  currentLink);
      //alert (jlink);
       if (jlink.trim() !== '') {
      links.push(jlink);
      cnt++;
      if (cnt==jPositionOnPage)
      {
       return jlink;
            
      }  
      }
      
      matchFound = false;
    }
  }

  return links.join('\n');
}



function extractLinks(string) {
  var match = string.trim().match(/(https?:\/\/\S+)/);

  if (match) {
    var link = match[1];
    link = link.replace(/"/g, ''); // Remove quotation marks
    return link;
  }

  return '';
}
  
 function extractHTML(htmlString, tagName) {
  const contents = [];
  let currentIndex = 0;
GoogleSearch=0;
  while (currentIndex < htmlString.length) {
    if (htmlString[currentIndex] === '<') {
      const closingAngleIndex = htmlString.indexOf('>', currentIndex);
      if (closingAngleIndex !== -1) {
        const tag = htmlString.substring(currentIndex, closingAngleIndex + 1);
        const normalizedTag = tag.toLowerCase();
        const normalizedTagName = tagName.toLowerCase();

        if (
          normalizedTag === `<${normalizedTagName}>` ||
          (normalizedTag.startsWith(`<${normalizedTagName} `) && normalizedTag.endsWith('>'))
        ) {
          let content = '';
          if (normalizedTagName === 'img') {
            const srcStartIndex = tag.toLowerCase().indexOf('src=') + 5;
            const srcEndIndex = tag.indexOf('"', srcStartIndex);
            content = tag.substring(srcStartIndex, srcEndIndex);
          } else if (normalizedTagName === 'a') {
            if (GoogleSearch === 1) {
              const parentClass = tag.substring(0, tag.indexOf('<a')).trim();
              if (parentClass.includes('yuRUbf')) {
                const hrefStartIndex = tag.toLowerCase().indexOf('href=') + 6;
                const hrefEndIndex = tag.indexOf('"', hrefStartIndex);
                content = tag.substring(hrefStartIndex, hrefEndIndex);
              }
            } else {
              const hrefStartIndex = tag.toLowerCase().indexOf('href=') + 6;
              const hrefEndIndex = tag.indexOf('"', hrefStartIndex);
              content = tag.substring(hrefStartIndex, hrefEndIndex);
            }
          } else {
            content = htmlString.substring(closingAngleIndex + 1, htmlString.indexOf('<', closingAngleIndex + 1)).trim();
          }
          contents.push(content);
        }

        currentIndex = closingAngleIndex + 1; // Move the current index to the character after the closing angle bracket
        continue;
      }
    }
    currentIndex++; // Move to the next character
  }

  return contents.join('\n\n');
}


function extractVariableFromString(inputString) {
  const regex = /{{(.*?)}}/;
  const match = inputString.match(regex);
  const extractedVariable = match ? match[1].trim() : '';
  return extractedVariable;
}


  window.addEventListener('message', async function(event) {
  

  if (event.data.type && event.data.type == 'googlesearchresult') {
	
		//alert(jData);
      if (jRound==1)
      {
          jRound=0;
    var jData = event.data.data;
    //alert(jData);
    //ToastEX2("Scrape Successful", jData);
    if (jData.includes("TABSTASK"))
    {
		//alert("TABSTASK");
     var myArray = jData.split("***"); 
     var jfPrompt = myArray[1];
     var myArray2 = jData.split("HTML***"); 
     var jTexts = "";
     var cnt = 0;
     for (let k of myArray2)
     {
        if (cnt>0)
       //jTexts += "TEXT"+cnt.toString()+": "+k+ " ";
	   jTexts += "TEXT"+cnt.toString()+": "+k+ " ";
     
     
     cnt++;
     }
	 
	 MegaPrompt = jTexts;
     //alert ("tabs task");
	// alert ("texts length:"+jTexts.length.toString()+" " +jfPrompt+ " "+jTexts);   
     
/*
	 jOpenAiRound = 1;
      await Openairequest (jfPrompt, jTexts); 
      //alert ("Here3");  
         await new Promise(resolve => {
      const interval = setInterval(() => {
        if (jOpenAiRound === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });
	*/


      
      // jReturnedOpenAiText = content;
       // jOpenAiRound = 0;
       
      //******************************
     // globalVariables.jPluginResponse = jReturnedOpenAiText;
    //********************************
     //MegaPrompt = MegaPrompt+jReturnedOpenAiText;
      jWaiting = 0;
	  jTabRequestWaiting=0;
	//  globalVariables.jIsPluginOn =1;

	//globalVariables.jPluginResponse = MegaPrompt;
	  // jRound=1;
	  /*
	  stopConversationRef.current = true;
      setTimeout(() => {
    stopConversationRef.current = false;
    console.log("stopConversationRef.current set to true after 5 seconds");
}, 5000);

*/
      //jOpenAiRound = 0;
        
    }
    
    
    if (jData.includes("TABSHTMLTASK"))
    {
	//alert("TABSHTMLTASK");
       // alert(jData);
     var myArray = jData.split("***"); 
     var jfPrompt = myArray[1];
     //alert (jfPrompt);
     var myArray2 = jData.split("HTMLSOURCE***"); 
     var jTexts = myArray2[1];
     //alert (jTexts);
    // alert ("texts length:"+jTexts.length.toString()+" " +jfPrompt+ "$$$$ANDTHISTEXT$$$$ "+jTexts);   
     
   var extractedVariable = extractVariableFromString(myArray[1]);
   var jnHTMLsource = extractHTML(jTexts, extractedVariable);
  // ToastEX2("Tags Extracted", jnHTMLsource);
  // alert (jnHTMLsource);
   /*
   globalVariables.jPluginResponse = jnHTMLsource;
   */
    //MegaPrompt = MegaPrompt+jnHTMLsource;
	jnHTMLsource = jnHTMLsource.replace(/\n/g, '<br>');
	MegaPrompt += jnHTMLsource;
	//alert (MegaPrompt);
	if (jOutline==0)
	{
   jWaiting = 0;
   
   //onSend({ role: 'user', content }, plugin);
   //setContent('');
   //setPlugin(null);

    if (window.innerWidth < 640 && textareaRef && textareaRef.current) {
      textareaRef.current.blur();
    }
	}
	else
	{
	
	
	jOutlineWaiting = 0;
	
	
	
	}
    
    //jRound = 1;
    // return; 
      
        
    }
    
    
     if (jData.includes("ChatGPTexperimental"))
    {
     // alert ("ChatGPTexperimental");
     var myArray = jData.split("***"); 
     ChatGPTResponse = myArray[1];
        
  // ToastEX2("ChatGPT Response", ChatGPTResponse);
   
   //jWaiting = 0;
   jChatGPTRequestWaiting = 0;
   // alert (ChatGPTResponse);    
    }
    
    if (jData.includes("TAGSTASK"))
	{
	
	//alert (jData);
	MegaPrompt += jData;
	jRound=1;
	jOutlineWaiting = 0;
	
	
	
	
	
	
	
	}
    
    
    
    
    
    
    
    
    
    
    
    
    if (jData.includes("URLTASK"))
    {
	//alert ("V2-urltask");
   // alert (jData);  
	//alert ("V2-urltask");
    var myArray = jData.split("***");  
    
	


      
      // jReturnedOpenAiText = content;
       // jOpenAiRound = 0;
       /*
      globalVariables.jPluginResponse = jReturnedOpenAiText;
      */
	   MegaPrompt += myArray[3];
	  // alert (MegaPrompt);
      //  MegaPrompt = MegaPrompt+jReturnedOpenAiText;
      jWaiting = 0;

	
		jRound = 1;














       
        
    }
    
    if (jData.includes("URLSOURCE"))
    {
     //////////////////////alert ("URLSOURCE");   
    var myArray = jData.split("***");  
   //alert( myArray[1]+" : "+myArray[3]);
  // alert( jData);
   
   
   var extractedVariable = extractVariableFromString(myArray[1]);
   var jnHTMLsource = "";
   if (GoogleSearch==2)
   {
    GoogleSearch=0;   
    MegaPrompt = MegaPrompt+myArray[3]; 
   jWaiting = 0;
   jRound = 1;
   //alert ("here");
       
   }
   
   else if (GoogleSearch==1)
   {
    GoogleSearch=0;
	jOutlineGoogleLinks = jData;
    jnHTMLsource= findLinksInHtmlEX(jData);
	//alert (jnHTMLsource);
	//var jfContent = jGooglePrompt+ " {{url:"+jnHTMLsource+"}}";
   // window.postMessage({ type: "myExtensionMessage", data: "url***"+jfContent }, "*");
	
	//jOutlineGoogleLinks = jData;
	MegaPrompt = jnHTMLsource; 
	jWaiting = 0;
	jRound = 1;
	if (window.innerWidth < 640 && textareaRef && textareaRef.current) {
      textareaRef.current.blur();
    }
	
    }
	else 
	{
	
	//alert (jData);
   var myArray = jData.split("***");
   MegaPrompt = myArray[3]; 
   jWaiting = 0;
	
	
	}
	}
    console.log('CHATUIPRO Received message from content script:');
   }
  }
});


function sanitizeText(text) {
  // Define the regular expression pattern to match unwanted symbols
  var symbolRegex = /[^a-zA-Z0-9\s]/g;

  // Replace unwanted symbols with an empty string
  var sanitizedText = text.replace(symbolRegex, '');

  // Return the sanitized text
  return sanitizedText;
}

async function Openairequest(user_prompt, user_text)
 {
  // alert ("Prompt:" + user_prompt + "TEXT:" + user_text); 
    if ( window.ChatGPTon==1)
  {
      //var BigTextResponse = "";
      if (user_text.length>3000)
      {
          //alert ("here");
        PromptChunks = [];
        PromptChunks =   splitStringEX(user_text, 1000);
        RoundsCount = PromptChunks.length-1;
        functionBCounter = 0;
        ChatGPTRequestRound=1;
        
        
        async function intervalFunction() {
    //alert("ok");
    var tmpPrompt="";
    var endtmpPrompt="";
  var cnt = functionBCounter+1;
  if (ChatGPTRequestRound==1)
  {
    ChatGPTRequestRound=0;
        
     if (functionBCounter === 0) {
  tmpPrompt = 'Do not answer yet. This is just another part of the text I want to send you. Just receive and acknowledge as "Part 1/'+RoundsCount+' received" and wait for the next part.[START PART 1/'+RoundsCount+']';
  endtmpPrompt='[END PART 1/'+RoundsCount+'] Remember not answering yet. Just acknowledge you received this part with the message "Part 1/'+RoundsCount+' received" and wait for the next part.';
} else if (functionBCounter === RoundsCount) {
  tmpPrompt = '[START PART '+cnt+'/'+RoundsCount+']';
  endtmpPrompt='ALL PARTS SENT. Now you can continue processing the request.';
} else {
 tmpPrompt = 'Do not answer yet. This is just another part of the text I want to send you. Just receive and acknowledge as "Part '+cnt+'/'+RoundsCount+' received" and wait for the next part.[START PART '+cnt+'/'+RoundsCount+']';
  endtmpPrompt='[END PART '+cnt+'/'+RoundsCount+'] Remember not answering yet. Just acknowledge you received this part with the message "Part '+cnt+'/'+RoundsCount+' received" and wait for the next part.';
}
       let newStr = PromptChunks[functionBCounter].replace(/\n/g, " ");
       var sanitizedText = sanitizeText(newStr);
       //var sanitizedText = encodeURIComponent(newStr);
        var content = "ChatGPTexperimental:" + tmpPrompt+" "+sanitizedText+" "+endtmpPrompt; // Concatenate each string with the prefix
      await  functionC(content);  
      
      // ToastEX2("Response from ChatGPT Received", 'PART '+cnt+'/'+RoundsCount+' Sent');
      //alert ("HERE");
  functionBCounter++;
  ChatGPTRequestRound = 1; 
 if (functionBCounter === RoundsCount) {
          clearInterval(intervalID);
          signalToBreakLoop = true;
        }  
      
  }
  
}
        
        
      var intervalID;

      function startInterval() {
        intervalID = setInterval(intervalFunction, 1000);
      }

      var signalToBreakLoop = false;
      startInterval();

      await new Promise((resolve) => {
        const intervalCheck = setInterval(() => {
          if (functionBCounter >= RoundsCount) {
            clearInterval(intervalCheck);
            resolve();
          }
        }, 1000);
      });
      
      
      
     // alert ("here, last prompt:"+user_prompt);
      
      if (user_prompt===user_text)
      {
          
      ChatGPTResponse = "What is your question about this text?";    
          
      }
      else
      {
      
      await  functionC(user_prompt);    
      
     // ToastEX2("Response from ChatGPT Received", ChatGPTResponse);
      }
     //alert(ChatGPTResponse);
    jOpenAiRound = 0;
    jReturnedOpenAiText = ChatGPTResponse;
    jTabRequestWaiting = 0; 
      
      
      
      
      
    }  
    else
    {
        
           
      
    var content =  "ChatGPTexperimental:" + user_prompt;
     await functionC(content); 
     //ToastEX2("Response from ChatGPT Received", ChatGPTResponse);
     //alert(ChatGPTResponse);
    jOpenAiRound = 0;
    jReturnedOpenAiText = ChatGPTResponse;
    jTabRequestWaiting = 0;
    }
  }
  else
  {
  
   
   //alert (user_prompt)
   //alert (user_text);
   
  await old_method_ex(user_prompt, user_text);
  
  //alert ("ok");
   
   
   
   
   
   
   
   
   
   
   
   
   
   
  
   
   
   
   
   
   
   
   
   
   
   
   
  //alert ("DONE"); 
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
 


      
      
  }   
  
  
 // alert("here2");
     
 }
 
 
 async function python_old()
 {
 
 
  var jfMessage = user_prompt+"***"+user_text;
   if (jMegaPromptEX.includes("***"))
   jMegaPromptEX += user_text+ "  ";
   else
   jMegaPromptEX = user_text+"***  "+jMegaPromptEX;
   const postData = {
  message: jMegaPromptEX,
};
const url = 'https://app.seotraffic.ai/openai_ex.php';

const response = await fetch(url, {
  method: 'POST', // Use the HTTP POST method
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded', // Set the content type for form data
    // Add any other headers as needed
  },
  body: new URLSearchParams(postData).toString(), // Convert the data to a URL-encoded string
});

  
    if (response.ok) {
     const data = await response.text();
  console.log('PHP script result:', data);
const dataObject = JSON.parse(data);
jReturnedOpenAiText = dataObject.message;
//jReturnedOpenAiText = content;
    //ToastEX2("OpenAI API Response", jReturnedOpenAiText);
    jOpenAiRound = 0;
    jTabRequestWaiting = 0;

    }else {
      alert('Error:', response.status, response.statusText);
    }
   
 
 
 
 
 
 }
 
 async function old_method_ex(user_prompt, user_text) {
    // Use the provided AbortController or create a new one
    const localAbortController = new AbortController();

    // Access the signal from the controller
    const signal = localAbortController.signal;

    // Set a flag to track if the function should abort
    let shouldAbort = false;

    // Set a timeout to periodically check the condition
    const timeoutId = setTimeout(() => {
	/*
        if (stopConversationRef.current) {
            console.log('Conversation stopped. Aborting OpenAI API call.');
            localAbortController.abort();
            shouldAbort = true;
        }
		*/
    }, 1000); // Adjust the timeout duration as needed

    try {
        // Your existing code for making the API request
        var jApikey = jfOpenAiApiKey;
        var jChatDiscussionMessagesEX = [];
        var chunkSize = 4000;
        var cnt = 0;

        for (let i = 0; i < user_text.length; i += chunkSize) {
            var chunk = user_text.slice(i, i + chunkSize);
            jChatDiscussionMessagesEX.push({ "role": "user", "content": chunk });
            if (cnt > 10)
                break;
            cnt++;
        }

        const URL = "https://api.openai.com/v1/chat/completions";
        const payload = {
            //"model": "gpt-4-1106-preview",
			"model": "gpt-3.5-turbo-1106",
            "messages": jChatDiscussionMessagesEX.concat([{ "role": "user", "content": user_prompt }]),
            "temperature": 0.3,
            "top_p": 0.3,
            "n": 1,
            "stream": false,
            "presence_penalty": 0,
            "frequency_penalty": 0
			//"max_length": 4095 // Set the max_length parameter
			//"echo": true // Set echo to true
        };

        const headers = {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${jApikey}`
        };

        // Attach the signal to the Fetch API options
        const requestOptions = {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(payload),
            signal: signal,
        };

        // Check the flag to see if the function should abort
        if (shouldAbort) {
            console.log('Aborting function due to stopConversationRef.current');
            return;
        }

        const response = await fetch(URL, requestOptions);

        // Check if the response is successful
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        // Parse the JSON response
        const json_obj = await response.json();
        const content = json_obj.choices[0].message.content;
        console.log(content);
        jReturnedOpenAiText = content;
        //ToastEX2("OpenAI API Response", jReturnedOpenAiText);
        jOpenAiRound = 0;
        jTabRequestWaiting = 0;

    } catch (error) {
        console.error(error);
        var userResponse = confirm("OpenAI returned an error. Do you want to try again?");
        if (userResponse === true) {
            await old_method_ex(user_prompt, user_text);
        } else {
            alert("OK");
        }
    } finally {
        // Clear the timeout to prevent it from triggering after the function completes
        clearTimeout(timeoutId);
    }
}

function old_method()
{

  var jChatDiscussionMessagesEX=[];
  var chunkSize = 4000; 
   
  var cnt = 0;
  for (let i = 0; i < user_text.length; i += chunkSize) {
    var chunk=user_text.slice(i, i + chunkSize);
    //alert (chunk);
    jChatDiscussionMessagesEX.push({"role": "user", "content": chunk});
    if (cnt>10)
    break;
    cnt++;
  }
   
   
   //var ji = splitStringEXEX(user_text, 1000, jChatDiscussionMessagesEX);
  
   //var ji = splitString(user_text, 1000);
   console.log (jChatDiscussionMessagesEX);
   //alert (jChatDiscussionMessagesEX);
   var jApikey = jfOpenAiApiKey;
   const URL = "https://api.openai.com/v1/chat/completions";
const payload = {
    "model": "gpt-3.5-turbo-1106",
    //"model": "gpt-4-1106-preview",
    "messages": jChatDiscussionMessagesEX.concat([{"role": "user", "content": user_prompt}]),
    "temperature" : 0.7,
    "top_p": 1,
    "n" : 1,
    "stream": false,
    "presence_penalty":0,
    "frequency_penalty":0,
};

const headers = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${jApikey}`
};


return fetch(URL, {
    method: 'POST',
    headers: headers,
    body: JSON.stringify(payload)
})
.then(response => response.json())
.then(json_obj => {
    const content = json_obj.choices[0].message.content;
    
    jReturnedOpenAiText = content;
    //ToastEX2("OpenAI API Response", jReturnedOpenAiText);
    jOpenAiRound = 0;
    jTabRequestWaiting = 0;
       
})
.catch(error => {
    
});






}

function splitStringEXEX(str, chunkSize, jChatDiscussionMessagesEX) {
  const chunks = [];
  var cnt = 0;
  for (let i = 0; i < str.length; i += chunkSize) {
    var chunk=str.slice(i, i + chunkSize);
    //alert (chunk);
    jChatDiscussionMessagesEX.push({"role": "user", "content": chunk});
    if (cnt>10)
    break;
    cnt++;
  }
  return chunks;
}

function splitString(str, chunkSize) {
  const chunks = [];
  var cnt = 0;
  for (let i = 0; i < str.length; i += chunkSize) {
    var chunk=str.slice(i, i + chunkSize);
    //alert (chunk);
    jChatDiscussionMessages.push({"role": "user", "content": chunk});
    if (cnt>10)
    break;
    cnt++;
  }
  return chunks;
}

function splitStringEX(str, chunkSize) {
  const chunks = [];
  for (let i = 0; i < str.length; i += chunkSize) {
    var chunk = str.slice(i, i + chunkSize);
    chunks.push(chunk); // Add the chunk to the array
  }
  return chunks;
}


var jChatDiscussionMessages=[];


var jRound = 0;
var jOpenAiRound = 0;
var jWaiting = 0;
var jChatGPTRequestWaiting = 0;
var jTabRequestWaiting = 0;
var jReturnedOpenAiText = "";
var jMegaPromptEX = "";

function calculateStartValue(pageNumber) {
  const resultsPerPage = 10;
  const startValue = (pageNumber - 1) * resultsPerPage;

  return startValue;
}
  
function calculatePageNumber(linkPosition) {
  const resultsPerPage = 10;
  const pageNumber = Math.ceil(linkPosition / resultsPerPage);
  const positionOnPage = linkPosition % resultsPerPage;

  return {
    pageNumber,
    positionOnPage,
  };
}

async function ContentWrapperEX(id, url)
  {
    
    
     GoogleSearch=2;
     const replacedStr = url.replace(/ /g, '+');
     var kurl = "https://www.google.com/search?client=firefox-b-d&q="+replacedStr;
     var jid = id.toString();
     var jurl = "{{urlsource:"+kurl+"}}";
     window.postMessage({ type: "myExtensionMessage", data: "source***"+"G"+jid+"$$$ " +jurl }, "*");
     jRound = 1;
    
      
      
      
      
  }

  async function ContentWrapper(id, url, linknumber)
  {
	// alert (url);
     const num = parseInt(linknumber);
     const { pageNumber, positionOnPage } = calculatePageNumber(num);
     const jStart=calculateStartValue (pageNumber);
     //alert (positionOnPage+ "  " + jStart);
	 jPositionOnPage = num;
     //jPositionOnPage = positionOnPage;
     GoogleSearch=1;
     const replacedStr = url.replace(/ /g, '+');
     var kurl = "https://www.google.com/search?client=firefox-b-d&q="+replacedStr+"&start="+jStart;
     var jid = id.toString();
     var jurl = "{{urlsource:"+kurl+"}}";
     window.postMessage({ type: "myExtensionMessage", data: "source***"+"G"+jid+"$$$ " +jurl }, "*");
     jRound = 1;
    
      
      
      
      
  }

/*  
function ToastEX2(jtext, jinternaltext) {
  const handleCopy = () => {
    const textToCopy = jinternaltext;
    navigator.clipboard.writeText(textToCopy)
      .then(() => {
        toast.success('Text copied to clipboard!');
      })
      .catch((error) => {
        toast.error('Failed to copy text to clipboard.');
        console.error(error);
      });
  };

  toast.custom((t) => (
    <div
      style={{
        background: '#343541',
        color: 'white',
        width: '400px',
        height: '100px',
		padding: '10px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
        fontFamily: 'Arial, sans-serif',
		borderRadius: '3px',
       
      }}
    >
      <div>{jtext}</div>
      <button onClick={handleCopy}>Copy</button>
    </div>
  ), {
    duration: 5000,
    position: 'bottom-right',
  });
}

function ToastEX(jtext)
{
 

  toast.custom((t) => (
    <div
      style={{
        background: '#444654',
        color: 'white',
        width: '400px',
        height: '100px',
		padding: '10px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
        fontFamily: 'Arial, sans-serif',
		borderRadius: '3px',
        
      }}
    >
      <div>{jtext}</div>
     </div>
   
  ), {
    duration: 5000,
    position: 'bottom-right',
  });
}
*/
async function functionA(part) {
var jTestPromis = 0;
  //ToastEX("functionA=" + part);
  var externalBoolean = false;
  //jOutlineTMPcheck = 1;
  //stopConversationRef.current = false;
  const contentProcessPromise = ContentProcess(part);

  const checkExternalBoolean = new Promise((resolve) => {
    const checkInterval = setInterval(() => {
	/*
       if (stopConversationRef.current === true) {
           jTestPromis = 1;
        clearInterval(checkInterval);
        resolve();
      }
	  */
    }, 1000);
  });

  await Promise.race([contentProcessPromise, checkExternalBoolean]);
  
 
 // alert(jTestPromis);
  
  
  
  
  
  
  
  
  
  
  
  
}

async function functionB(part) {
    MegaPrompt = MegaPrompt + part;
  //alert( "functionB="+part);
  // ToastEX("functionB="+part);
 await  Openairequest(MegaPrompt, MegaPrompt);
  
  MegaPrompt=jReturnedOpenAiText;
  
 // alert( MegaPrompt);
  
  
  // Perform operations on the last non-empty part
}

async function functionC(part) {
    //alert ("ok");
 // ToastEX("ChatGPTRequest="+part);
  //alert( "functionA="+part);
  
 // MegaPrompt = MegaPrompt + part;
  return new Promise(async (resolve) => {
    
    const result1 = await ContentProcess(part);
    //alert("here4");

    resolve();
  });
  
  
// alert ("out function"); 
  
   
}

 function jSendMessageToBackgroundScript(additionalData) {
  alert(additionalData);
  browser.runtime.sendMessage({ action: "executeScript", data: additionalData });
}
async function GateKeeper(content)
{

window.postMessage({ type: "myExtensionMessage", data: "ChatGPTPrompt***"+content+"***"+content }, "*"); 
     jRound = 1;
     jChatGPTRequestWaiting = 1;
     
    await new Promise(resolve => {
      const interval = setInterval(() => {
        if (jChatGPTRequestWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });





}
function sanitizeString(input) {
  if (typeof input !== 'string') {
    input = String(input); // Convert to a string
  }

  return input
    .replace(/'/g, "\\'") // Escape single quotes
    .replace(/"/g, '\\"');  // Escape double quotes
}

 function showCustomAlert() {
            // Prompt the user to enter a new message
            const editedMessage = window.prompt("Enter a new message:");

            if (editedMessage !== null) { // Check if the user didn't cancel
                // Update the displayed message
                document.getElementById("message").innerText = editedMessage;
                // You can also send the edited message to your server here
            }
        }
var jGateKeeperMessage = '';
async function OpenaiGateKeeperEX(user_prompt, user_text) {
    // Use the provided AbortController or create a new one
    const localAbortController = new AbortController();
	
	//user_text = user_text.replace(/(\r\n|\n|\r)/gm, "");

    // Access the signal from the controller
    const signal = localAbortController.signal;

    // Set a flag to track if the function should abort
    let shouldAbort = false;

    // Set a timeout to periodically check the condition
    const timeoutId = setTimeout(() => {
	/*
        if (stopConversationRef.current) {
            console.log('Conversation stopped. Aborting OpenAI API call.');
            localAbortController.abort();
            shouldAbort = true;
        }
		*/
    }, 1000); // Adjust the timeout duration as needed

    try {
        // Your existing code for making the API request
        var jApikey = jfOpenAiApiKey;
        var jChatDiscussionMessagesEX = [];
        var chunkSize = 50000;
        var cnt = 0;

        for (let i = 0; i < user_text.length; i += chunkSize) {
            var chunk = user_text.slice(i, i + chunkSize);
			//var encodedChunk = encodeURIComponent(chunk);
            jChatDiscussionMessagesEX.push({ "role": "user", "content": chunk });
            if (cnt > 10)
                break;
            cnt++;
        }

        const URL = "https://api.openai.com/v1/chat/completions";
        const payload = {
            //"model": "gpt-4-1106-preview",
			"model": "gpt-3.5-turbo-1106",
			//"model": "gpt-3.5-turbo",
            "messages": jChatDiscussionMessagesEX.concat([{ "role": "user", "content": user_prompt }]),
            "temperature": 0.3,
            "top_p": 0.3,
            "n": 1,
            "stream": false,
            "presence_penalty": 0,
            "frequency_penalty": 0
			//"max_length": 4095, // Set the max_length parameter
			//"echo": true // Set echo to true
        };

        const headers = {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${jApikey}`
        };

        // Attach the signal to the Fetch API options
        const requestOptions = {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(payload),
            signal: signal,
        };

        // Check the flag to see if the function should abort
        if (shouldAbort) {
            console.log('Aborting function due to stopConversationRef.current');
            return;
        }

        const response = await fetch(URL, requestOptions);

        // Check if the response is successful
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
		const jsonString = JSON.stringify(payload);
		//alert ("complete request:"+ jsonString);
		const payloadSizeInBytes = new TextEncoder().encode(jsonString).length;
		//alert (payloadSizeInBytes);
        const json_obj = await response.json();
        const content = json_obj.choices[0].message.content;
        jGateKeeperMessage = content.replace(/</g, "&lt;").replace(/>/g, "&gt;");
       // ToastEX2("OpenAI API Response", jGateKeeperMessage);

    } catch (error) {
        // Handle errors here
        console.error(error);
    } finally {
        // Clear the timeout to prevent it from triggering after the function completes
        clearTimeout(timeoutId);
    }
}

async function OpenaiGateKeeper(content)
{
const postData = {
  message: content,
};
const url = 'https://app.seotraffic.ai/openai.php';

const response = await fetch(url, {
  method: 'POST', // Use the HTTP POST method
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded', // Set the content type for form data
    // Add any other headers as needed
  },
  body: new URLSearchParams(postData).toString(), // Convert the data to a URL-encoded string
});

  
    if (response.ok) {
     const data = await response.text();
  console.log('PHP script result:', data);
const dataObject = JSON.parse(data);
jGateKeeperMessage = dataObject.message;

    }else {
      alert('Error:', response.status, response.statusText);
    }







}
async function ContentProcessEX(content, updatedConversation) {
//showCustomAlert();
//alert (content);
if (content.toLowerCase().includes("seotraffic")) {
	var match = content.match(/seotraffic,\s*(.*)/i);

if (match) {
    content = match[1];
    // Now 'extractedText' contains the text following "seotraffic" (and any following commas and whitespace)
    console.log(content);
}
   // content = content.replace(/seotraffic/gi, '');

GateKeeperPrompt = GateKeeperPrompt.replace(/\n/g, ' ');
//GateKeeperPrompt= sanitizeString(GateKeeperPrompt);
var jfcontent = "";
if (GateKeeperFirstTime==0)
{

jfcontent =  "ChatGPTexperimental:"+ GateKeeperPrompt+" INPUT "+content;
GateKeeperFirstTime = 1;
}
else
{
jfcontent =  "ChatGPTexperimental: Create an OUTPUT  INPUT "+content;

}
   if ( window.ChatGPTon==1)
  {
 //alert ("api off");
 await GateKeeper(jfcontent);
 }
 else
 {
// alert ("api on");
 await OpenaiGateKeeperEX(content, GateKeeperPrompt);
 ChatGPTResponse = jGateKeeperMessage;
 //alert (ChatGPTResponse);
 }
 /*
 if  (stopConversationRef.current === true)
		{
		return;
		}
 
 */
 let jPopup = true;
function decodeHtmlEntities(text) {
    var textArea = document.createElement('textarea');
    textArea.innerHTML = text;
    return textArea.value;
}
// Function to open the popup
function openPopup() {
    // Create a div element for the popup window
    const overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.bottom = '0';
    overlay.style.left = '0';
    overlay.style.right = '0';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    overlay.style.display = 'flex';
    overlay.style.justifyContent = 'center';
    overlay.style.alignItems = 'center';
    overlay.style.zIndex = '9999';

    // Create popup
    const popup = document.createElement('div');
    popup.style.backgroundColor = 'grey';
    popup.style.padding = '20px';
    popup.style.borderRadius = '5px';
    popup.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.1)';
    popup.style.position = 'relative';
    popup.style.width = '400px'; // Make the popup wider

    // Create close button
    const closeButton = document.createElement('a');
    closeButton.textContent = '×';
    closeButton.style.position = 'absolute';
    closeButton.style.top = '5px';
    closeButton.style.right = '10px';
    closeButton.style.cursor = 'pointer';
    closeButton.onclick = function() {
        document.body.removeChild(overlay);
        jPopup = false;
    };
	const decodedResponse = decodeHtmlEntities(ChatGPTResponse);
    // Create editable content area
    const editableContent = document.createElement('textarea');
    editableContent.style.width = '100%';
    editableContent.style.height = '200px';
    editableContent.textContent = decodedResponse; // Set initial text to ChatGPTResponse

    // Create confirm button
    const confirmButton = document.createElement('button');
    confirmButton.textContent = 'CONFIRM';
    confirmButton.style.marginTop = '10px';
    confirmButton.onclick = function() {
        ChatGPTResponse = editableContent.value; // Update ChatGPTResponse with the edited text
        document.body.removeChild(overlay);
        jPopup = false;
    };

    // Append elements
    popup.appendChild(closeButton);
    popup.appendChild(editableContent);
    popup.appendChild(confirmButton);
    overlay.appendChild(popup);
    document.body.appendChild(overlay);
}


// Function to wait for the popup to be closed


// Open the popup

async function waitForPopup() {
    await new Promise(resolve => {
        const interval = setInterval(() => {
            if (jPopup === false) {
                clearInterval(interval);
                resolve();
            }
        }, 100);
    });
}

openPopup();
await waitForPopup();


/*
if  (stopConversationRef.current === true)
		{
		return;
		}

*/



//alert (ChatGPTResponse);






ChatGPTResponse = ChatGPTResponse.replace("OUTPUTEND", "");
ChatGPTResponse = ChatGPTResponse.replace("OUTPUT", "");

//alert ("GateKeeper- debug regime "+ globalVariables.jPluginContent);
MegaPrompt = ChatGPTResponse;
return;
//alert (content);
}
if (! content.includes("{{wp"))
{  
var jK = 1;
var jRole = '';
  if (! content.includes("<<Step"))
      content="<<Step1>> "+content;
  MegaPrompt = "";
  jLabel = '';
  var jPreviousLabel = '';
  jLabelStatus = false;
  var parts = content.split("<<Step");
  var numParts = parts.length;
	
  for (var i = 1; i < numParts; i++) {
 // alert ("PARTS:"+parts[i]);
 /*
 if  (stopConversationRef.current === true)
		{
		return;
		}
		*/
    var currentPart = parts[i].trim();
    if (currentPart !== "") {
      var stepEndIndex = currentPart.indexOf(">>");
      if (stepEndIndex !== -1) {
        var step = currentPart.substring(0, stepEndIndex + 2);
        var sentence = currentPart.substring(stepEndIndex + 2).trim();
        var delimitedPart = `${step} ${sentence}`;
		var jTMPbool = false;
		if (jLabelStatus==true)
		{
		jPreviousLabel = jLabel;
		jTMPbool = true;
		
		
		}
		else
		{
		jPreviousLabel = '';
		jTMPbool = false;
		
		}
		
		if (delimitedPart.includes("LABEL"))
		{
		jLabelStatus = true;;
		let parts = delimitedPart.split("LABEL");

	if (parts.length === 2) {
    delimitedPart = parts[0].trim();
    jLabel = parts[1].trim();
	}	
		
		}
		else
		{
		jLabelStatus = false;
		jLabel = '';
		
		}
		if (jTMPbool==true)
		{
		delimitedPart = "<<Step" + delimitedPart+' '+jPreviousLabel+'/n:'+MegaPrompt;
		
		
		}
		else
		{
        delimitedPart = "<<Step" + delimitedPart+' '+MegaPrompt;
		}
		//alert ("HERE-v2 "+delimitedPart);
		
		if (jK ==1)
		{
		jRole = 'user';
		jK=2;
		}
		else
		{
		jK = 1;
		jRole = 'assistant';
		
		}
		
		delimitedPart = delimitedPart.replace("OUTPUTEND", "");
		MegaPrompt = MegaPrompt.replace("OUTPUTEND", "");
		
		/*
		const newAssistantMessage1: Message = { role: jRole, content: delimitedPart };
		updatedConversation = {
		...updatedConversation,
		messages: [...updatedConversation.messages, newAssistantMessage1],
		};

		homeDispatch({ field: 'selectedConversation', value: updatedConversation });
		updatedConversationsArray.push (updatedConversation);
		textConversationsArray.push(delimitedPart);
		*/
		
		
		
		
		
		
		
		
		
		
		
        if (numParts === 2) {
		//alert ("parts: 2");
		//alert ("HERE: v2");
          // Execute functionA when there is only one step
          await functionA(delimitedPart);
		  //alert ("HERE: v2-c");
        } else if (i === numParts - 1) {
		//alert ("HERE: v2=B");
          // Apply functionB to the last non-empty part
		 // alert (delimitedPart);
          //alert ("Megaprompt "+MegaPrompt);
          // MegaPrompt = MegaPrompt+delimitedPart;
		   //MegaPrompt = delimitedPart;
		 // alert ("Megaprompt2"+MegaPrompt);
          await Openairequest(delimitedPart, MegaPrompt);
          MegaPrompt+=jReturnedOpenAiText;
		  
		  const newAssistantMessage1: Message = { role: jRole, content: MegaPrompt };
		  
		/*
		updatedConversation = {
		...updatedConversation,
		messages: [...updatedConversation.messages, newAssistantMessage1],
		};

		homeDispatch({ field: 'selectedConversation', value: updatedConversation });
		updatedConversationsArray.push (updatedConversation);
		textConversationsArray.push(MegaPrompt);
		*/  
		  
		  
		  
		  
         // alert( MegaPrompt);
        } else {
	//	alert ("parts: 1");
		//alert ("HERE" + delimitedPart);
          // Apply functionA to non-empty parts except the last one
          await functionA(delimitedPart);
		 // alert ("HERE2" + delimitedPart);
        }
      }
    }
  
  }


//alert ("here waiting");


//alert (MegaPrompt);
if (jPostPrompt==1)
{
jPostPrompt = 0;
}
else
{
GlobalPromptString = MegaPrompt;
}
}
if (content.includes("{{wp"))
{
//alert (content);
var sessionValue = localStorage.getItem('seotrafficsession');
if (content.includes("list_domains"))
await GetWpData(sessionValue);
if (content.includes("show_apikey"))
MegaPrompt= sessionValue;
if (content.includes("get_categories"))
{
var regex = /wp:(.*?)\.get_categories/;
var match = content.match(regex);

if (match) {
  var domainName = match[1];
  var result = await GetWPcategories(domainName);
  MegaPrompt = result;
  }

}
if (content.includes("create_categories"))
{
const regex = /\{\{wp:([^:]+)\.create_categories\(([^)]+)\)\}\}/;
const match = content.match(regex);
if (match) {
    const domainName = match[1];
    const categoriesString = match[2];
    const categoriesArray = categoriesString.includes(',') ? categoriesString.split(',').map(category => category.trim()) : [categoriesString.trim()];
	  
	for (const category of categoriesArray) {
    try {
      const result = await InsertWPcategories(domainName, category);
      console.log(`Category ${category} inserted for domain ${domainName}. Result:`, result);
    } catch (error) {
      console.error(`Error inserting category ${category} for domain ${domainName}:`, error);
      // Handle the error as needed
    }
	}
	
	MegaPrompt = domainName+"created categories: "+categoriesString;
    


}

}
if (content.includes("get_posts()"))
{
var regex = /wp:(.*?)\.get_posts/;
var match = content.match(regex);

if (match) {
  var domainName = match[1];
  var result = await GetWPpostsUrls(domainName);
  MegaPrompt = result;
  }

}
if (content.includes("get_posts.title"))
{
var regex = /wp:(.*?)\.get_posts.title/;
var match = content.match(regex);

if (match) {
  var domainName = match[1];
  var result = await GetWPpostsTitles(domainName);
  MegaPrompt = result;
  //alert (MegaPrompt);
  }

}
}
//alert("This is MegaPrompt V2"+MegaPrompt);
//globalVariables.jPluginResponse = MegaPrompt;
//globalVariables.jIsPluginOn =1;


  //alert("This is MegaPrompt"+MegaPrompt);
  
}

async function GetWPpostsTitles(domainName) {
  const postData = new URLSearchParams();
  postData.append("domainName", domainName);

  const url = "https://"+domainName+"/wp-content/plugins/seotraffic/php/get_post_titles.php";

  const options = {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: postData,
  };

  try {
    const response = await fetch(url, options);
    const result = await response.text();
    console.log(result); // Handle the result from the server

    return result; // Return the result from the function
  } catch (error) {
    console.error("Error:", error);
    throw error; // Propagate the error to the caller
  }
}
async function GetWPpostsUrls(domainName) {
  const postData = new URLSearchParams();
  postData.append("domainName", domainName);

  const url = "https://"+domainName+"/wp-content/plugins/seotraffic/php/get_post_urls.php";

  const options = {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: postData,
  };

  try {
    const response = await fetch(url, options);
    const result = await response.text();
    console.log(result); // Handle the result from the server

    return result; // Return the result from the function
  } catch (error) {
    console.error("Error:", error);
    throw error; // Propagate the error to the caller
  }
}
async function InsertWPcategories(domainName, categoryname) {
  const postData = new URLSearchParams();
  postData.append("category", categoryname);

  const url = "https://"+domainName+"/wp-content/plugins/seotraffic/php/insert_categories.php";

  const options = {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: postData,
  };

  try {
    const response = await fetch(url, options);
    const result = await response.text();
    console.log(result); // Handle the result from the server

    return result; // Return the result from the function
  } catch (error) {
    console.error("Error:", error);
    throw error; // Propagate the error to the caller
  }
}
async function GetWPcategories(domainName) {
  const postData = new URLSearchParams();
  postData.append("domainName", domainName);

  const url = "https://"+domainName+"/wp-content/plugins/seotraffic/php/get_categories.php";

  const options = {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: postData,
  };

  try {
    const response = await fetch(url, options);
    const result = await response.text();
    console.log(result); // Handle the result from the server

    return result; // Return the result from the function
  } catch (error) {
    console.error("Error:", error);
    throw error; // Propagate the error to the caller
  }
}
async function GetWpData(sessionValue)
{
MegaPrompt="";
  const postData = {
  apikey: sessionValue,
};
const url = 'https://app.seotraffic.ai/client_get_list_of_domains.php';

const response = await fetch(url, {
  method: 'POST', // Use the HTTP POST method
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded', // Set the content type for form data
    // Add any other headers as needed
  },
  body: new URLSearchParams(postData).toString(), // Convert the data to a URL-encoded string
});

  
    if (response.ok) {
     const dataObject  = await response.json();
  //console.log('PHP script result:', data);
dataObject.forEach(domain => {
      MegaPrompt += domain;
    });
//MegaPrompt = dataObject.message;


}



}
async  function ContentProcess(content)
  {
  //  alert ("ContentProcess:"+content);  
   if (content.includes("[compare:"))
    {
     var myArray = content.split("compare:");
     window.postMessage({ type: "myExtensionMessage", data: "compareresearch***"+myArray[1] }, "*");
     jRound = 1;
     return;   
        
        
        
    }
    
   else if (content.includes("{{find"))
    {
        
     
    const str = "{{find dentists leads on linekdin.com}}";

// Extracting the word between "{{" and "}}"
    const regexWord = /{{(.*?)}}/;
    const wordMatch = str.match(regexWord);
    const word = wordMatch ? wordMatch[1].trim() : "";

// Extracting the domain name after the last whitespace
    const regexDomain = /(\S+)$/;
    const domainMatch = str.match(regexDomain);
    const domain = domainMatch ? domainMatch[1] : "";

    console.log("Word:", word);
    console.log("Domain:", domain);

    
    window.postMessage({ type: "myExtensionMessage", data: "leadsresearch***"+word+"***"+domain }, "*");
     jRound = 1;
     return;   
        
        
        
    }
    
   else if (content.includes("{{tab:"))
    {
        
      //  alert (content);
    /*    
    globalVariables.jIsPluginOn = 1;    
    globalVariables.jPluginRequest = content;
    */
    //MegaPrompt = MegaPrompt+content;
    //var input = "Summarize [tab1] and [tab2] and compare why the 2 articles come to a different conclusion";
    var pattern = /\{\{tab:\d+\}\}/g;
    var tabs = content.match(pattern);
    var jtext = content.replace(pattern, "");
   
  // Extract the tab numbers from the matched strings and join them into a string
    var tabNumbers = tabs.map(function(tab) {return tab.match(/\d+/)[0];}).join("###");
    
    window.postMessage({ type: "myExtensionMessage", data: "tabsresearch***"+jtext+"***"+tabNumbers }, "*");
     jRound = 1;
     
     jTabRequestWaiting = 1;
    await new Promise(resolve => {
      const interval = setInterval(() => {
	  /*
	    if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jTabRequestWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });

   //alert("HERE-TAB5");
  }
    
    
    
    
    
   
    
    else if (content.includes("ChatGPTexperimental"))
    {
   
   // alert ("ChatGPTexperimental!!!!:"+content);
   window.postMessage({ type: "myExtensionMessage", data: "ChatGPTPrompt***"+content+"***"+content }, "*"); 
     jRound = 1;
     jChatGPTRequestWaiting = 1;
     
    await new Promise(resolve => {
      const interval = setInterval(() => {
	  /*
		if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
	  
	  
        if (jChatGPTRequestWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });
	
	//alert ("here");

    //return;
  }
    
    
    
    
    
    
    
    
    
    
   else if (content.includes("{{tabsource:"))
    {
        /*
    globalVariables.jIsPluginOn = 1;    
    globalVariables.jPluginRequest = content;  
*/    
     //MegaPrompt = MegaPrompt+content;
    //var input = "Summarize [tab1] and [tab2] and compare why the 2 articles come to a different conclusion";
    var pattern = /\{\{tabsource:\d+\}\}/g;
    var tabs = content.match(pattern);
    var jtext = content.replace(pattern, "");
   
  // Extract the tab numbers from the matched strings and join them into a string
    var tabNumbers = tabs.map(function(tab) {return tab.match(/\d+/)[0];}).join("###");
    
    window.postMessage({ type: "myExtensionMessage", data: "tabshtmlresearch***"+jtext+"***"+tabNumbers }, "*");
     jRound = 1;
     jWaiting = 1;
     
    await new Promise(resolve => {
      const interval = setInterval(() => {
	  /*
	  if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });
    //  alert   (MegaPrompt);
        
        
    }
    
  else   if (content.includes("{{url:"))
    {
        /*
     globalVariables.jIsPluginOn = 1;    
     globalVariables.jPluginRequest = content;
     */
     //MegaPrompt = MegaPrompt+content;
     //var myArray = content.split("[url:");
     window.postMessage({ type: "myExtensionMessage", data: "url***"+content }, "*");
     jRound = 1;
     jWaiting = 1;
     
    await new Promise(resolve => {
      const interval = setInterval(() => {
	  /*
	  if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });  
        
        
        
    }
	
   else if (content.includes("{{post"))
   {
   jPostPrompt = 1;
await OpenaiGateKeeperEX(GlobalPromptString, PostGateKeeperPrompt);

const parsedObject = parseWPStringToObject(jGateKeeperMessage);
console.log (parsedObject);

const title = parsedObject['title'];
const body = parsedObject['body'];
const meta = parsedObject['meta'];
const schema = parsedObject['schema'];
const slug = parsedObject['slug'];
console.log('Title:', title);
console.log('Body:', body);
console.log('Meta:', meta);
console.log('Schema:', schema);
console.log('Slug:', slug);
if (title !== undefined && body !== undefined)
{
// Displaying the results
console.log('Title:', title);
console.log('Body:', body);
console.log('Meta:', meta);
console.log('Schema:', schema);
console.log('Slug:', slug);
//alert (jGateKeeperMessage);
const postData = new URLSearchParams();
postData.append("title", title);
postData.append("content", body);
postData.append("schema", schema);

const url = "https://croms-revenge.de/wp-content/plugins/seotraffic/php/webhook-handler.php";

const options = {
  method: "POST",
  headers: {
    "Content-Type": "application/x-www-form-urlencoded", // Set the content type for form data
  },
  body: postData,
};

fetch(url, options)
  .then(response => response.text())
  .then(result => {
    console.log(result); // Handle the result from the server
  })
  .catch(error => {
    console.error("Error:", error);
  });


   
   
   
   
   alert ("Post performed successfully");
   }
   else
   {
   alert ("Something Went wrong");
   
   }
   
   
   }
   else if (content.includes ("{{image:"))
   {
  // {{image: "Sustainable living in urban environments, green spaces, eco-friendly practices", "medium", "center", "Urban green space", "Eco-friendly urban living", "true"}}

  // const formula = '{{image: "Sustainable living in urban environments, green spaces, eco-friendly practices", "medium", "center", "Urban green space", "Eco-friendly urban living", "true"}}';

var pattern = /{{image: "(.*?)", "(.*?)", "(.*?)", "(.*?)", "(.*?)", "(.*?)"}}/;

var match = content.match(pattern);

if (match) {
    var params = {
        imagePrompt: match[1],
        size: match[2],
        alignment: match[3],
        altText: match[4],
        caption: match[5],
        setFeatured: match[6]
    };

    console.log(params);
} else {
    console.log("No match found.");
}
   var generatedImageUrl = await GenerateImg(params.imagePrompt);
   
   //alert (generatedImageUrl);
   MegaPrompt =  '<img src=\"'+generatedImageUrl+'" alt="Descriptive Alt Text">';
   
   }
   else  if (content.includes("{{urlsource:"))
    {
      /*  
    globalVariables.jIsPluginOn = 1;    
    globalVariables.jPluginRequest = content;
    */
    //MegaPrompt = MegaPrompt+content;
     //var myArray = content.split("[url:");
     window.postMessage({ type: "myExtensionMessage", data: "source***"+content }, "*");
     jRound = 1;
     jWaiting = 1;
     
    await new Promise(resolve => {
	
      const interval = setInterval(() => {
	  /*
	  if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });   
        
        
        
    }
  else if (content.match(/{{paa/i)) {
  //alert(content);
  pattern = /{{paa:(.*?)}}/i;
  var match = content.match(pattern);
  const stringToSearch = match[1];
  // Rest of your code...
 
     //alert(stringToSearch);
      ContentWrapperEX(200, stringToSearch);
          
        jWaiting = 1;
     
    await new Promise(resolve => {
      const interval = setInterval(() => {
	  /*
	  if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });   









     
            
            
        }
	else if (content.includes("{{tag"))
	{
	if (content.includes ("tab:"))
	{
	jOutlineString = "";
	var result = parseTagTab(content);
	
	jOutlineTags = JSON.stringify(result.tags);
	var tabNumbers =  result.tabValue;
	window.postMessage({ type: "myExtensionMessage", data: "tabstagsresearch***"+jOutlineTags+"***"+tabNumbers }, "*");
	jRound=1;
	jOutlineWaiting = 1;
     
    await new Promise(resolve => {
	
      const interval = setInterval(() => {
	  /*
	  if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jOutlineWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    }); 
	
	var jArr = MegaPrompt.split("***");  
	//alert (jArr[2]);
	jOutlineString+= jArr[2];
	
	
	
	}
	if (content.includes("url:"))
	{
	
	var result = parseTagUrl(content);
	
	jOutlineString = "";
	
	
	jOutlineTags = JSON.stringify(result.tags);
	var jkUrl =  result.url;
	
	var jfContent = jkUrl+"***"+jOutlineTags;
    window.postMessage({ type: "myExtensionMessage", data: "tags***"+jfContent }, "*");
	
	jRound=1;
	jOutlineWaiting = 1;
     
    await new Promise(resolve => {
      const interval = setInterval(() => {
	  /*
	  if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jOutlineWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    }); 
	
	var jArr = MegaPrompt.split("***");  
	//alert (jArr[2]);
	jOutlineString+= jArr[2];
	
	
	
	
	
	
	
	
	}
	
	
	MegaPrompt = jOutlineString; 
	jWaiting = 0;
	
	}
	else if (content.includes("{{extract"))
	{
	//alert (content);
		
	var jkResult = parseFormula(content);
	console.log('Headings:', jkResult.headings);
  console.log('Number:', jkResult.number);
  console.log('Keyword:', jkResult.keyword);
  console.log('Domains:', jkResult.domains);
	//alert (jkResult);
  jOutlineTags = "";
  jOutlineTags = JSON.stringify(jkResult.headings);
  jOutlineDomainsEx = [];
  jOutlineDomainsEx = jkResult.domains;
  jOutlineKeyword = jkResult.keyword;
  jOutlineString = "";
  jOutline = 1;
  jOutlineTMPcheck = 1;
  jGoogleSearchType = 1;
  jOutlinePages = jkResult.number;
  ContentWrapper(100, jOutlineKeyword, 1);
          
   jWaiting = 1;
     
    await new Promise(resolve => {
      const interval = setInterval(() => {
	  /*
	  if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    }); 
	
	for (var x = 0; x<jOutlinePages; x++)
	{
	var y = x+1;
	jPositionOnPage = y;
	var jkUrl = findLinksInHtmlEX(jOutlineGoogleLinks);
	var jCheckDomain = 0;
	if (jOutlineDomainsEx.length > 0)
	{
	
	for (let item of jOutlineDomainsEx) {
	item = item.trim();
	
    if (jkUrl.toLowerCase().includes(item.toLowerCase())) {
        jCheckDomain = 1;
    }
	
	}
	
	
	
	
	
	
	}
	
	if (jCheckDomain==1)
	continue;
	
	
	var jfContent = jkUrl+"***"+jOutlineTags;
    window.postMessage({ type: "myExtensionMessage", data: "tags***"+jfContent }, "*");
	
	jRound=1;
	jOutlineWaiting = 1;
     
    await new Promise(resolve => {
      const interval = setInterval(() => {
	  /*
	  if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jOutlineWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    }); 
	
	var jArr = MegaPrompt.split("***");  
	//alert (jArr[2]);
	jOutlineString+= jArr[2];
	
	
	
	
	}
	
	//alert (jOutlineString);
	MegaPrompt = jOutlineString; 
	jWaiting = 0;
	jOutlineTMPcheck = 0;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
   
}




	
	
	
   else if (content.includes("{{google"))
        {
       if (content.includes("googlesource"))
           jGoogleSearchType = 1;
       else
           jGoogleSearchType=0;
      var jGooglePromptTMP =   content.split("{{google"); 
      //alert (jGoogleSearchType);
      jGooglePrompt = jGooglePromptTMP[0];
      /*
     globalVariables.jIsPluginOn = 1;    
    globalVariables.jPluginRequest = content;
    */
    //MegaPrompt = MegaPrompt+content;
	//alert (content);
    var result = "";
    var LinkNumber = "";
    const regex = /{{(google|googlesource)(\d+):([^}]*)/;
    const match = content.match(regex);

if (match) {
  LinkNumber = match[2];
 // alert (LinkNumber);
  result = match[3];
  //console.log("Page Number:", pageNumber);
  console.log("Result:", result);
}

 //  alert (LinkNumber+"  "+result);
    ContentWrapper(100, result, LinkNumber);
          
    jWaiting = 1;
     
    await new Promise(resolve => {
      const interval = setInterval(() => {
	  /*
	  if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });  
	
	
	
	
	
	var jfContent = jGooglePrompt+ " {{url:"+MegaPrompt+"}}";
    window.postMessage({ type: "myExtensionMessage", data: "url***"+jfContent }, "*");
	jWaiting = 1;
     
    await new Promise(resolve => {
      const interval = setInterval(() => {
	  /*
	  if  (stopConversationRef.current === true)
		{
		clearInterval(interval);
        resolve();
		}
		*/
        if (jWaiting === 0) {
          clearInterval(interval);
          resolve();
        }
      }, 100);
    });  

	



	
            
            
        }
    
  else  if (content.includes("[google:"))
    {
     var myArray = content.split(":");
     window.postMessage({ type: "myExtensionMessage", data: "googlesearch***"+myArray[1] }, "*");
     jRound = 1;
     return;
    }  
else {

      //  alert("This is content :"+content);
      await Openairequest(content, content);
          MegaPrompt=jReturnedOpenAiText  ;



    }    
      
      
      
      
      
      
      
      
      
  }
async function GenerateImg(keyword) {
    let url = '';
    let abortController = new AbortController();

    // Set your OpenAI API key
    const OPENAI_API_KEY = jfOpenAiApiKey;

    // Set the API endpoint URL
    const api_url = "https://api.openai.com/v1/images/generations";
    // const keyword = "handmade, heritage, niche focus, vintage reselling, $500";

    // Set the request data
    const requestData = {
        model: "dall-e-2",
        prompt: "A bright, inviting scene with diverse objects signifies " + keyword + " Dont add  TEXT PLEASE",
        n: 1,
        size: "512x512"
    };

    // Set the Fetch API options
    const requestOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + OPENAI_API_KEY
        },
        signal: abortController.signal,  // Associate the signal with the request options
        body: JSON.stringify(requestData)
    };

    // Function to handle aborting the request
	
	/*
    const handleAbort = () => {
        abortController.abort();
        console.log('Request aborted');
    };

   
    if (stopConversationRef.current === true) {
        handleAbort();
        return url;
    }
*/
    try {
        // Make the API request using the Fetch API
        const response = await fetch(api_url, requestOptions);

        // Check if the response is successful
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        // Parse the JSON response
        const data = await response.json();

        // Check if decoding was successful and the 'data' key exists
        if (data.data && data.data[0] && data.data[0].url) {
            // Access the URL
            url = data.data[0].url;
            console.log("URL: " + url);
        } else {
            throw new Error('Invalid JSON format or missing "url" key.');
        }
    } catch (error) {
        if (error.name === 'AbortError') {
            console.log('Request aborted by the user');
            // Handle user-abort logic if needed
        } else {
            console.error('Error:', error.message);
        }
    }

    return url;
}
function decodeEntities(input) {
  const txt = document.createElement('textarea');
  txt.innerHTML = input;
  return txt.value;
}
function parseWPStringToObject(input) {
 const decodedInput = decodeEntities(input);
 const regex = /<<wp-(\w+)>>((?:.|\n)+?)<</g;
  let match;
  const result = {};

  while ((match = regex.exec(decodedInput)) !== null) {
    const [, section, content] = match;
    result[section] = content.trim();
  }

  return result;
} 
function extractAndConvert(input) {
  if (typeof input === 'string' && input.length > 0) {
    if (input.length === 1) {
      const number = parseInt(input, 10);
      return [number];
    } else if (input.length === 2) {
      const number1 = parseInt(input[0], 10);
      const number2 = parseInt(input[1], 10);
      return [number1, number2];
    }
  }
  // Handle invalid input or empty string
  return null;
}
function parseTagUrl(inputString) {
  // Define a regular expression pattern
  const regex = /\{\{tag:\[([^\]]*)\],\s*url:([^\}]*)\}\}/;

  // Use the exec method to match the pattern against the input string
  const match = regex.exec(inputString);

  // Check if there's a match
  if (match) {
    // Extract values from the matched groups
    const tags = match[1].split(',').map(tag => tag.trim());
    const url = match[2].trim();

    // Return the result
    return { tags, url };
  } else {
    // Return null or handle the case where there's no match
    return null;
  }
}
function parseTagTab(inputString) {
  // Define a regular expression pattern
  const regex = /\{\{tag:\[([^\]]*)\],\s*tab:(\d+)\}\}/;

  // Use the exec method to match the pattern against the input string
  const match = regex.exec(inputString);

  // Check if there's a match
  if (match) {
    // Extract values from the matched groups
    const tags = match[1].split(',').map(tag => tag.trim());
    const tabValue = parseInt(match[2], 10);

    // Return the result
    return { tags, tabValue };
  } else {
    // Return null or handle the case where there's no match
    return null;
  }
}
function parseFormula(formula) {
  const pattern = /{{[^{]*\[([^\]]+)]\s*,\s*(\d+)\s*,\s*([^,\]]+)(?:,\s*\[([^\]]+)]\s*)?[^}]*}}/;
  
  const match = formula.match(pattern);

  console.log('Formula:', formula);
  console.log('Match:', match);

  if (match) {
    const headings = match[1].split(',');
    const number = parseInt(match[2], 10);
    const keyword = match[3].trim();
    const domains = match[4] ? match[4].split(',') : [];
    
    return {
      headings,
      number,
      keyword,
      domains,
    };
  }

  console.error('Invalid formula format');
  return null;
}



//seotraffic
import { createChatFiles } from "@/db/chat-files"
import { createChat } from "@/db/chats"
import { createMessageFileItems } from "@/db/message-file-items"
import { createMessages, updateMessage } from "@/db/messages"
import { uploadMessageImage } from "@/db/storage/message-images"
import {
  buildFinalMessages,
  buildGoogleGeminiFinalMessages
} from "@/lib/build-prompt"
import { consumeReadableStream } from "@/lib/consume-stream"
import { Tables, TablesInsert } from "@/supabase/types"
import {
  ChatFile,
  ChatMessage,
  ChatPayload,
  ChatSettings,
  LLM,
  MessageImage
} from "@/types"
import React from "react"
import { toast } from "sonner"
import { v4 as uuidv4 } from "uuid"

export const validateChatSettings = (
  chatSettings: ChatSettings | null,
  modelData: LLM | undefined,
  profile: Tables<"profiles"> | null,
  selectedWorkspace: Tables<"workspaces"> | null,
  messageContent: string
) => {
  if (!chatSettings) {
    throw new Error("Chat settings not found")
  }

  if (!modelData) {
    throw new Error("Model not found")
  }

  if (!profile) {
    throw new Error("Profile not found")
  }

  if (!selectedWorkspace) {
    throw new Error("Workspace not found")
  }

  if (!messageContent) {
    throw new Error("Message content not found")
  }
}

export const handleRetrieval = async (
  userInput: string,
  newMessageFiles: ChatFile[],
  chatFiles: ChatFile[],
  embeddingsProvider: "openai" | "local",
  sourceCount: number
) => {
  const response = await fetch("/api/retrieval/retrieve", {
    method: "POST",
    body: JSON.stringify({
      userInput,
      fileIds: [...newMessageFiles, ...chatFiles].map(file => file.id),
      embeddingsProvider,
      sourceCount
    })
  })

  if (!response.ok) {
    console.error("Error retrieving:", response)
  }

  const { results } = (await response.json()) as {
    results: Tables<"file_items">[]
  }

  return results
}

export const createTempMessages = (
  messageContent: string,
  chatMessages: ChatMessage[],
  chatSettings: ChatSettings,
  b64Images: string[],
  isRegeneration: boolean,
  setChatMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>,
  selectedAssistant: Tables<"assistants"> | null
) => {
  let tempUserChatMessage: ChatMessage = {
    message: {
      chat_id: "",
      assistant_id: null,
      content: messageContent,
      created_at: "",
      id: uuidv4(),
      image_paths: b64Images,
      model: chatSettings.model,
      role: "user",
      sequence_number: chatMessages.length,
      updated_at: "",
      user_id: ""
    },
    fileItems: []
  }

  let tempAssistantChatMessage: ChatMessage = {
    message: {
      chat_id: "",
      assistant_id: selectedAssistant?.id || null,
      content: "",
      created_at: "",
      id: uuidv4(),
      image_paths: [],
      model: chatSettings.model,
      role: "assistant",
      sequence_number: chatMessages.length + 1,
      updated_at: "",
      user_id: ""
    },
    fileItems: []
  }

  let newMessages = []

  if (isRegeneration) {
    const lastMessageIndex = chatMessages.length - 1
    chatMessages[lastMessageIndex].message.content = ""
    newMessages = [...chatMessages]
  } else {
    newMessages = [
      ...chatMessages,
      tempUserChatMessage,
      tempAssistantChatMessage
    ]
  }

  setChatMessages(newMessages)

  return {
    tempUserChatMessage,
    tempAssistantChatMessage
  }
}

export const handleLocalChat = async (
  payload: ChatPayload,
  profile: Tables<"profiles">,
  chatSettings: ChatSettings,
  tempAssistantMessage: ChatMessage,
  isRegeneration: boolean,
  newAbortController: AbortController,
  setIsGenerating: React.Dispatch<React.SetStateAction<boolean>>,
  setFirstTokenReceived: React.Dispatch<React.SetStateAction<boolean>>,
  setChatMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>,
  setToolInUse: React.Dispatch<React.SetStateAction<string>>
) => {
  const formattedMessages = await buildFinalMessages(payload, profile, [])

  // Ollama API: https://github.com/jmorganca/ollama/blob/main/docs/api.md
  const response = await fetchChatResponse(
    process.env.NEXT_PUBLIC_OLLAMA_URL + "/api/chat",
    {
      model: chatSettings.model,
      messages: formattedMessages,
      options: {
        temperature: payload.chatSettings.temperature
      }
    },
    false,
    newAbortController,
    setIsGenerating,
    setChatMessages
  )

  return await processResponse(
    response,
    isRegeneration
      ? payload.chatMessages[payload.chatMessages.length - 1]
      : tempAssistantMessage,
    false,
    newAbortController,
    setFirstTokenReceived,
    setChatMessages,
    setToolInUse
  )
}

export const handleHostedChat = async (
  payload: ChatPayload,
  profile: Tables<"profiles">,
  modelData: LLM,
  tempAssistantChatMessage: ChatMessage,
  isRegeneration: boolean,
  newAbortController: AbortController,
  newMessageImages: MessageImage[],
  chatImages: MessageImage[],
  setIsGenerating: React.Dispatch<React.SetStateAction<boolean>>,
  setFirstTokenReceived: React.Dispatch<React.SetStateAction<boolean>>,
  setChatMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>,
  setToolInUse: React.Dispatch<React.SetStateAction<string>>
) => {
  const provider =
    modelData.provider === "openai" && profile.use_azure_openai
      ? "azure"
      : modelData.provider

  let formattedMessages = []

  if (provider === "google") {
    formattedMessages = await buildGoogleGeminiFinalMessages(
      payload,
      profile,
      newMessageImages
    )
  } else {
    formattedMessages = await buildFinalMessages(payload, profile, chatImages)
  }

  const apiEndpoint =
    provider === "custom" ? "/api/chat/custom" : `/api/chat/${provider}`

  const requestBody = {
    chatSettings: payload.chatSettings,
    messages: formattedMessages,
    customModelId: provider === "custom" ? modelData.hostedId : ""
  }


const lastMessageContent = requestBody.messages[requestBody.messages.length - 1]?.content;
  var updatedConversation = '';
  jSeotrafficActive = false;
  await ContentProcessEX(lastMessageContent, updatedConversation);
  //alert ('ok');
//seotraffic
 /* 
  const response = await fetchChatResponse(
    apiEndpoint,
    requestBody,
    true,
    newAbortController,
    setIsGenerating,
    setChatMessages
  )
 */ 
let modifiedText = MegaPrompt; // Modify the response text as needed. This is just a placeholder.
let modifiedResponse = new Response(MegaPrompt, {
  status: 200, // Simulate a successful HTTP status code
  statusText: "OK",
  headers: { 'Content-Type': 'text/plain' } // Adjust as needed
});

  return await processResponse(
    modifiedResponse,
    isRegeneration
      ? payload.chatMessages[payload.chatMessages.length - 1]
      : tempAssistantChatMessage,
    true,
    newAbortController,
    setFirstTokenReceived,
    setChatMessages,
    setToolInUse
  )
}
  
  /*const response = await fetchChatResponse(
    apiEndpoint,
    requestBody,
    true,
    newAbortController,
    setIsGenerating,
    setChatMessages
  )

  return await processResponse(
    response,
    isRegeneration
      ? payload.chatMessages[payload.chatMessages.length - 1]
      : tempAssistantChatMessage,
    true,
    newAbortController,
    setFirstTokenReceived,
    setChatMessages,
    setToolInUse
  )
}
*/

export const fetchChatResponse = async (
  url: string,
  body: object,
  isHosted: boolean,
  controller: AbortController,
  setIsGenerating: React.Dispatch<React.SetStateAction<boolean>>,
  setChatMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>
) => {
  const response = await fetch(url, {
    method: "POST",
    body: JSON.stringify(body),
    signal: controller.signal
  })

  if (!response.ok) {
    if (response.status === 404 && !isHosted) {
      toast.error(
        "Model not found. Make sure you have it downloaded via Ollama."
      )
    }

    const errorData = await response.json()

    toast.error(errorData.message)

    setIsGenerating(false)
    setChatMessages(prevMessages => prevMessages.slice(0, -2))
  }

  return response
}

export const processResponse = async (
  response: Response,
  lastChatMessage: ChatMessage,
  isHosted: boolean,
  controller: AbortController,
  setFirstTokenReceived: React.Dispatch<React.SetStateAction<boolean>>,
  setChatMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>,
  setToolInUse: React.Dispatch<React.SetStateAction<string>>
) => {
  let fullText = ""
  let contentToAdd = ""

  if (response.body) {
    await consumeReadableStream(
      response.body,
      chunk => {
        setFirstTokenReceived(true)
        setToolInUse("none")

        try {
          contentToAdd = isHosted
            ? chunk
            : // Ollama's streaming endpoint returns new-line separated JSON
              // objects. A chunk may have more than one of these objects, so we
              // need to split the chunk by new-lines and handle each one
              // separately.
              chunk
                .trimEnd()
                .split("\n")
                .reduce(
                  (acc, line) => acc + JSON.parse(line).message.content,
                  ""
                )
          fullText += contentToAdd
        } catch (error) {
          console.error("Error parsing JSON:", error)
        }

        setChatMessages(prev =>
          prev.map(chatMessage => {
            if (chatMessage.message.id === lastChatMessage.message.id) {
              const updatedChatMessage: ChatMessage = {
                message: {
                  ...chatMessage.message,
                  content: fullText
                },
                fileItems: chatMessage.fileItems
              }

              return updatedChatMessage
            }

            return chatMessage
          })
        )
      },
      controller.signal
    )

    return fullText
  } else {
    throw new Error("Response body is null")
  }
}

export const handleCreateChat = async (
  chatSettings: ChatSettings,
  profile: Tables<"profiles">,
  selectedWorkspace: Tables<"workspaces">,
  messageContent: string,
  selectedAssistant: Tables<"assistants">,
  newMessageFiles: ChatFile[],
  setSelectedChat: React.Dispatch<React.SetStateAction<Tables<"chats"> | null>>,
  setChats: React.Dispatch<React.SetStateAction<Tables<"chats">[]>>,
  setChatFiles: React.Dispatch<React.SetStateAction<ChatFile[]>>
) => {
  const createdChat = await createChat({
    user_id: profile.user_id,
    workspace_id: selectedWorkspace.id,
    assistant_id: selectedAssistant?.id || null,
    context_length: chatSettings.contextLength,
    include_profile_context: chatSettings.includeProfileContext,
    include_workspace_instructions: chatSettings.includeWorkspaceInstructions,
    model: chatSettings.model,
    name: messageContent.substring(0, 100),
    prompt: chatSettings.prompt,
    temperature: chatSettings.temperature,
    embeddings_provider: chatSettings.embeddingsProvider
  })

  setSelectedChat(createdChat)
  setChats(chats => [createdChat, ...chats])

  await createChatFiles(
    newMessageFiles.map(file => ({
      user_id: profile.user_id,
      chat_id: createdChat.id,
      file_id: file.id
    }))
  )

  setChatFiles(prev => [...prev, ...newMessageFiles])

  return createdChat
}

export const handleCreateMessages = async (
  chatMessages: ChatMessage[],
  currentChat: Tables<"chats">,
  profile: Tables<"profiles">,
  modelData: LLM,
  messageContent: string,
  generatedText: string,
  newMessageImages: MessageImage[],
  isRegeneration: boolean,
  retrievedFileItems: Tables<"file_items">[],
  setChatMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>,
  setChatFileItems: React.Dispatch<
    React.SetStateAction<Tables<"file_items">[]>
  >,
  setChatImages: React.Dispatch<React.SetStateAction<MessageImage[]>>,
  selectedAssistant: Tables<"assistants"> | null
) => {
  const finalUserMessage: TablesInsert<"messages"> = {
    chat_id: currentChat.id,
    assistant_id: null,
    user_id: profile.user_id,
    content: messageContent,
    model: modelData.modelId,
    role: "user",
    sequence_number: chatMessages.length,
    image_paths: []
  }

  const finalAssistantMessage: TablesInsert<"messages"> = {
    chat_id: currentChat.id,
    assistant_id: selectedAssistant?.id || null,
    user_id: profile.user_id,
    content: generatedText,
    model: modelData.modelId,
    role: "assistant",
    sequence_number: chatMessages.length + 1,
    image_paths: []
  }

  let finalChatMessages: ChatMessage[] = []

  if (isRegeneration) {
    const lastStartingMessage = chatMessages[chatMessages.length - 1].message

    const updatedMessage = await updateMessage(lastStartingMessage.id, {
      ...lastStartingMessage,
      content: generatedText
    })

    chatMessages[chatMessages.length - 1].message = updatedMessage

    finalChatMessages = [...chatMessages]

    setChatMessages(finalChatMessages)
  } else {
    const createdMessages = await createMessages([
      finalUserMessage,
      finalAssistantMessage
    ])

    // Upload each image (stored in newMessageImages) for the user message to message_images bucket
    const uploadPromises = newMessageImages
      .filter(obj => obj.file !== null)
      .map(obj => {
        let filePath = `${profile.user_id}/${currentChat.id}/${
          createdMessages[0].id
        }/${uuidv4()}`

        return uploadMessageImage(filePath, obj.file as File).catch(error => {
          console.error(`Failed to upload image at ${filePath}:`, error)
          return null
        })
      })

    const paths = (await Promise.all(uploadPromises)).filter(
      Boolean
    ) as string[]

    setChatImages(prevImages => [
      ...prevImages,
      ...newMessageImages.map((obj, index) => ({
        ...obj,
        messageId: createdMessages[0].id,
        path: paths[index]
      }))
    ])

    const updatedMessage = await updateMessage(createdMessages[0].id, {
      ...createdMessages[0],
      image_paths: paths
    })

    const createdMessageFileItems = await createMessageFileItems(
      retrievedFileItems.map(fileItem => {
        return {
          user_id: profile.user_id,
          message_id: createdMessages[1].id,
          file_item_id: fileItem.id
        }
      })
    )

    finalChatMessages = [
      ...chatMessages,
      {
        message: updatedMessage,
        fileItems: []
      },
      {
        message: createdMessages[1],
        fileItems: retrievedFileItems.map(fileItem => fileItem.id)
      }
    ]

    setChatFileItems(prevFileItems => {
      const newFileItems = retrievedFileItems.filter(
        fileItem => !prevFileItems.some(prevItem => prevItem.id === fileItem.id)
      )

      return [...prevFileItems, ...newFileItems]
    })

    setChatMessages(finalChatMessages)
  }
}
