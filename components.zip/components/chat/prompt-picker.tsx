import { ChatbotUIContext } from "@/context/context"
import { Tables } from "@/supabase/types"
import { FC, useContext, useEffect, useRef, useState } from "react"
import { Button } from "../ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog"
import { Label } from "../ui/label"
import { TextareaAutosize } from "../ui/textarea-autosize"
import { usePromptAndCommand } from "./chat-hooks/use-prompt-and-command"
var jtmpDomain = "";
interface PromptPickerProps {}

export const PromptPicker: FC<PromptPickerProps> = ({}) => {
  const {
    prompts,
    isPromptPickerOpen,
    setIsPromptPickerOpen,
    focusPrompt,
    slashCommand
  } = useContext(ChatbotUIContext)

  const { handleSelectPrompt } = usePromptAndCommand()

  const itemsRef = useRef<(HTMLDivElement | null)[]>([])

  const [promptVariables, setPromptVariables] = useState<
    {
      promptId: string
      name: string
      value: string
    }[]
  >([])
  const [showPromptVariables, setShowPromptVariables] = useState(false)

  useEffect(() => {
  console.warn ("PromptPicker"+slashCommand);
    if (focusPrompt && itemsRef.current[0]) {
      itemsRef.current[0].focus()
    }
  }, [focusPrompt])

  const [isTyping, setIsTyping] = useState(false)

  const filteredPrompts = prompts.filter(prompt =>
    prompt.name.toLowerCase().includes(slashCommand.toLowerCase())
  )

  const handleOpenChange = (isOpen: boolean) => {
    setIsPromptPickerOpen(isOpen)
  }

  const callSelectPrompt = (prompt: Tables<"prompts">) => {
    const regex = /\{\{.*?\}\}/g
    const matches = prompt.content.match(regex)

    if (matches) {
      const newPromptVariables = matches.map(match => ({
        promptId: prompt.id,
        name: match.replace(/\{\{|\}\}/g, ""),
        value: ""
      }))
		//alert(newPromptVariables)
      setPromptVariables(newPromptVariables)
      setShowPromptVariables(true)
    } else {
	  console.log (prompt)

      handleSelectPrompt(prompt)
      handleOpenChange(false)
    }
  }

  const getKeyDownHandler =
    (index: number) => (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (e.key === "Backspace") {
        e.preventDefault()
        handleOpenChange(false)
      } else if (e.key === "Enter") {
        e.preventDefault()
        callSelectPrompt(filteredPrompts[index])
      } else if (
        (e.key === "Tab" || e.key === "ArrowDown") &&
        !e.shiftKey &&
        index === filteredPrompts.length - 1
      ) {
        e.preventDefault()
        itemsRef.current[0]?.focus()
      } else if (e.key === "ArrowUp" && !e.shiftKey && index === 0) {
        // go to last element if arrow up is pressed on first element
        e.preventDefault()
        itemsRef.current[itemsRef.current.length - 1]?.focus()
      } else if (e.key === "ArrowUp") {
        e.preventDefault()
        const prevIndex =
          index - 1 >= 0 ? index - 1 : itemsRef.current.length - 1
        itemsRef.current[prevIndex]?.focus()
      } else if (e.key === "ArrowDown") {
        e.preventDefault()
        const nextIndex = index + 1 < itemsRef.current.length ? index + 1 : 0
        itemsRef.current[nextIndex]?.focus()
      }
    }

  const handleSubmitPromptVariables = () => {
    const newPromptContent = promptVariables.reduce(
      (prevContent, variable) =>
        prevContent.replace(
          new RegExp(`\\{\\{${variable.name}\\}\\}`, "g"),
          variable.value
        ),
      prompts.find(prompt => prompt.id === promptVariables[0].promptId)
        ?.content || ""
    )

    const newPrompt: any = {
      ...prompts.find(prompt => prompt.id === promptVariables[0].promptId),
      content: newPromptContent
    }

    handleSelectPrompt(newPrompt)
    handleOpenChange(false)
    setShowPromptVariables(false)
    setPromptVariables([])
  }

  const handleCancelPromptVariables = () => {
    setShowPromptVariables(false)
    setPromptVariables([])
  }

  const handleKeydownPromptVariables = (
    e: React.KeyboardEvent<HTMLDivElement>
  ) => {
    if (!isTyping && e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmitPromptVariables()
    }
  }
 const [showAnotherContext, setShowAnotherContext] = useState(false);
 const [showASD, setShowASD] = useState(true);
 const resetShowAnotherContext = () => {
  setShowAnotherContext(false);
  console.warn ("setting to true");
  // setShowASD(true);
};
const [testArray, setTestArray] = useState([]);
const [hasFetchedItems, setHasFetchedItems] = useState(false);

useEffect(() => {
  if (!hasFetchedItems) {
    setTestArray(['item1', 'item2', 'item3']);
    setHasFetchedItems(true);
  }
}, [hasFetchedItems]);

const AnotherContext = () => {
  const [highlightedItem, setHighlightedItem] = useState(null);

  return (
    <div className="bg-background flex flex-col space-y-1 rounded-xl border-2 p-2 text-sm">
      {showAnotherContext && (
        <>
         
          <div
            className={`hover:bg-accent focus:bg-accent flex cursor-pointer flex-col rounded p-2 focus:outline-none ${
              highlightedItem === 2 ? 'bg-accent' : ''
            }`}
            onMouseEnter={() => setHighlightedItem(1)}
            onMouseLeave={() => setHighlightedItem(null)}
            onClick={() => {
               prompt = 	{
  "id": "",
  "name": "",
  "content": "ASD***{{wp:show_apikey}}",
  "sharing": "private",
  "user_id": "",
  "folder_id": null,
  "created_at": "2024-03-11T01:27:52.625397+00:00",
  "updated_at": null
}
resetShowAnotherContext();
      handleSelectPrompt(prompt)
      handleOpenChange(false)
            }}
          >
            show_apikey
          </div>
          <div
            className={`hover:bg-accent focus:bg-accent flex cursor-pointer flex-col rounded p-2 focus:outline-none ${
              highlightedItem === 3 ? 'bg-accent' : ''
            }`}
            onMouseEnter={() => setHighlightedItem(2)}
            onMouseLeave={() => setHighlightedItem(null)}
            onClick={() => {
               prompt = 	{
  "id": "",
  "name": "",
  "content": "ASD***{{wp:"+jtmpDomain2+".get_categories}}",
  "sharing": "private",
  "user_id": "",
  "folder_id": null,
  "created_at": "2024-03-11T01:27:52.625397+00:00",
  "updated_at": null
}
resetShowAnotherContext();
      handleSelectPrompt(prompt)
      handleOpenChange(false)
            }}
          >
            get_categories
          </div>
		  
		  
		  
		  <div
            className={`hover:bg-accent focus:bg-accent flex cursor-pointer flex-col rounded p-2 focus:outline-none ${
              highlightedItem === 3 ? 'bg-accent' : ''
            }`}
            onMouseEnter={() => setHighlightedItem(3)}
            onMouseLeave={() => setHighlightedItem(null)}
            onClick={() => {
               prompt = 	{
  "id": "",
  "name": "",
  "content": "ASD***{{wp:"+jtmpDomain2+".create_categories(arg)}}",
  "sharing": "private",
  "user_id": "",
  "folder_id": null,
  "created_at": "2024-03-11T01:27:52.625397+00:00",
  "updated_at": null
}
resetShowAnotherContext();
      handleSelectPrompt(prompt)
      handleOpenChange(false)
            }}
          >
            create_categories
          </div>
		  
		  <div
            className={`hover:bg-accent focus:bg-accent flex cursor-pointer flex-col rounded p-2 focus:outline-none ${
              highlightedItem === 3 ? 'bg-accent' : ''
            }`}
            onMouseEnter={() => setHighlightedItem(4)}
            onMouseLeave={() => setHighlightedItem(null)}
            onClick={() => {
               prompt = 	{
  "id": "",
  "name": "",
  "content": "ASD***{{wp:"+jtmpDomain2+".get_posts}}",
  "sharing": "private",
  "user_id": "",
  "folder_id": null,
  "created_at": "2024-03-11T01:27:52.625397+00:00",
  "updated_at": null
}
resetShowAnotherContext();
      handleSelectPrompt(prompt)
      handleOpenChange(false)
            }}
          >
            get_posts
          </div>
		  
		  
		  <div
            className={`hover:bg-accent focus:bg-accent flex cursor-pointer flex-col rounded p-2 focus:outline-none ${
              highlightedItem === 3 ? 'bg-accent' : ''
            }`}
            onMouseEnter={() => setHighlightedItem(5)}
            onMouseLeave={() => setHighlightedItem(null)}
            onClick={() => {
               prompt = 	{
  "id": "",
  "name": "",
  "content": "ASD***{{wp:"+jtmpDomain2+".get_posts.title}}",
  "sharing": "private",
  "user_id": "",
  "folder_id": null,
  "created_at": "2024-03-11T01:27:52.625397+00:00",
  "updated_at": null
}
resetShowAnotherContext();
      handleSelectPrompt(prompt)
      handleOpenChange(false)
            }}
          >
            get_posts_title
          </div>
		  
		  
		  
        </>
      )}
    </div>
  );
};
 const { profile } = useContext(ChatbotUIContext);
  const username = profile?.username;
  const [jtmpDomain2, setJtmpDomain] = useState('');
const [jtmpDomains, setJtmpDomains] = useState([]);
  // Function to get credentials
  async function GetWpData(username) {
    let MegaPrompt = "";
    const postData = {
      apikey: username,
    };
    const url = 'https://app.seotraffic.ai/client_get_list_of_domains.php';

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams(postData).toString(),
      });

      if (response.ok) {
        const dataObject = await response.json();
        dataObject.forEach(domain => {
          MegaPrompt += domain + "***";
        });
      }
      return MegaPrompt;
    } catch (error) {
      console.error('Error fetching data:', error);
      return ''; // Return an empty string or handle the error as needed
    }
  }
const [refreshKey, setRefreshKey] = useState(0);
const [hasFetchedDomains, setHasFetchedDomains] = useState(false);

useEffect(() => {
  if (isPromptPickerOpen && window.wp ) {
    GetWpData(username).then(domain => {
      console.warn(domain);
      const domainsArray = domain.split('***'); 
      setJtmpDomains(domainsArray);
      setHasFetchedDomains(true);
	   setRefreshKey(prevKey => prevKey + 1);
    });
  }
}, [isPromptPickerOpen, window.wp, username, hasFetchedDomains]);


 return (
  <>
    {isPromptPickerOpen && (
      <>
        {window.wp ? (
          <div key={refreshKey} className="bg-background flex flex-col space-y-1 rounded-xl border-2 p-2 text-sm">
		  
            {!showAnotherContext &&  jtmpDomains.map((domain, index) => (
              <div
			    
                key={index}
                className="hover:bg-accent focus:bg-accent flex cursor-pointer flex-col rounded p-2 focus:outline-none"
                onClick={() => {
				 
   
                  setJtmpDomain(domain);
                  
				  setShowAnotherContext(true);
                  setShowASD(false);
                }}
              >
			  {<div className="font-bold">{domain}</div>}
               
               
              </div>
            ))}
          </div>
        ) : (
        <div className="bg-background flex flex-col space-y-1 rounded-xl border-2 p-2 text-sm">
          {showPromptVariables ? (
            <Dialog
              open={showPromptVariables}
              onOpenChange={setShowPromptVariables}
            >
              <DialogContent onKeyDown={handleKeydownPromptVariables}>
                <DialogHeader>
                  <DialogTitle>Enter Prompt Variables</DialogTitle>
                </DialogHeader>

                <div className="mt-2 space-y-6">
                  {promptVariables.map((variable, index) => (
                    <div key={index} className="flex flex-col space-y-2">
                      <Label>{variable.name}</Label>

                      <TextareaAutosize
                        placeholder={`Enter a value for ${variable.name}...`}
                        value={variable.value+"ASD"}
                        onValueChange={value => {
                          const newPromptVariables = [...promptVariables]
                          newPromptVariables[index].value = value
                          setPromptVariables(newPromptVariables)
                        }}
                        minRows={3}
                        maxRows={5}
                        onCompositionStart={() => setIsTyping(true)}
                        onCompositionEnd={() => setIsTyping(false)}
                      />
                    </div>
                  ))}
                </div>

                <div className="mt-2 flex justify-end space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCancelPromptVariables}
                  >
                    Cancel
                  </Button>

                  <Button size="sm" onClick={handleSubmitPromptVariables}>
                    Submit
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          ) : filteredPrompts.length === 0 ? (
            <div className="text-md flex h-14 cursor-pointer items-center justify-center italic hover:opacity-50">
              No matching prompts.
            </div>
          ) : (
            filteredPrompts.map((prompt, index) => (
              <div
                key={prompt.id}
                ref={ref => {
                  itemsRef.current[index] = ref
                }}
                tabIndex={0}
                className="hover:bg-accent focus:bg-accent flex cursor-pointer flex-col rounded p-2 focus:outline-none"
                onClick={() => callSelectPrompt(prompt)}
                onKeyDown={getKeyDownHandler(index)}
              >
                <div className="font-bold">{prompt.name}</div>

                <div className="truncate text-sm opacity-80">
                  {prompt.content}
                </div>
              </div>
            ))
          )}
        </div>
        )
		
		
		}
      </>
    )}

    {showAnotherContext &&  (
      <AnotherContext />
    )}
	{!showAnotherContext && (
      <div></div> // Render an empty div when showAnotherContext is false
    )}
  </>
);




  
}

